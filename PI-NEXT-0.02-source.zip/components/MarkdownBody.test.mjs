import assert from "node:assert/strict";
import test from "node:test";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import ReactMarkdown from "react-markdown";
import { createJiti } from "jiti";

const jiti = createJiti(import.meta.url, {
  jsx: { runtime: "automatic" },
  tsconfigPaths: true,
});
const { MarkdownBody } = await jiti.import("./MarkdownBody.tsx");
const { normalizeDisplayMath, markdownPreviewRemarkPlugins, markdownPreviewRehypePlugins, markdownRemarkPlugins, markdownRehypePlugins } = await jiti.import("../lib/markdown.ts");
const { I18nProvider } = await jiti.import("@/hooks/useI18n");

function renderMarkdown(markdown, props = {}) {
  return renderToStaticMarkup(
    React.createElement(
      I18nProvider,
      null,
      React.createElement(MarkdownBody, {
        cwd: "/home/me/project",
        onOpenFile() {},
        ...props,
      }, markdown),
    ),
  );
}

test("a document reader keeps local links in the page without an href", () => {
  const local = renderMarkdown("[relative](references/setup.md#config) [anchor](#config) [outside](../outside.md) [absolute](/etc/test.md) [attachment](image.png)", { onOpenFile: undefined, onNavigateLink() {} });
  assert.equal((local.match(/<a role="link" tabindex="0">/g) ?? []).length, 5);
  assert.doesNotMatch(local, /href=|target=|\snode=/);
  const external = renderMarkdown("[web](https://example.com) [mail](mailto:hello@example.com) [bad](javascript:alert%281%29)", { onOpenFile: undefined, onNavigateLink() {} });
  assert.equal((external.match(/target="_blank" rel="noopener noreferrer"/g) ?? []).length, 3);
  assert.doesNotMatch(external, /role="link"|javascript:|alert%28/);
  // Chat keeps its links as they were.
  assert.match(renderMarkdown("[relative](references/setup.md)", { onOpenFile: undefined }), /<a href="references\/setup.md" target="_blank"/);
});

test("a document reader keeps HTML anchor destinations and link labels", () => {
  const html = renderMarkdown('<a id="install"></a>\n\n<a href="guide.md" title="Read setup" aria-label="Setup guide">Next</a>\n\n[Jump](guide.md "Read the setup guide")', { onOpenFile: undefined, onNavigateLink() {} });
  assert.match(html, /<a id="user-content-install" target="_blank" rel="noopener noreferrer"><\/a>/);
  assert.match(html, /<a title="Read setup" aria-label="Setup guide" role="link" tabindex="0">Next<\/a>/);
  assert.match(html, /<a title="Read the setup guide" role="link" tabindex="0">Jump<\/a>/);
});

test("heading anchors are opt-in, scoped, formatted-text aware and generated before KaTeX", () => {
  const markdown = "# Setup **guide**!\n\n## Configuration\n\n## Configuration\n\n## Configuration-1\n\n## Configuration\n\n## 中文 标题\n\n## `code` & punctuation.\n\n## Compute $x$";
  assert.doesNotMatch(renderMarkdown(markdown), /data-heading-anchor/);
  const html = renderMarkdown(markdown, { onNavigateLink() {} });
  const anchors = [...html.matchAll(/data-heading-anchor="([^"]*)"/g)].map((match) => match[1]);
  assert.deepEqual(anchors, ["setup-guide", "configuration", "configuration-1", "configuration-1-1", "configuration-2", "中文-标题", "code--punctuation", "compute-x"]);
  assert.doesNotMatch(html, /\sid=/);
  assert.match(html, /class="katex"/);
  assert.equal(renderMarkdown(markdown, { onNavigateLink() {} }), html, "new renders restart the slug sequence");
});

test("renders CJK sentence emphasis without spaces after closing punctuation", () => {
  const sentence = "今天天气很好。";
  const markdown = `**${sentence}**我们去公园散步吧。`;
  for (const props of [{}, { keepLineBreaks: true }]) {
    const html = renderMarkdown(markdown, props);
    assert.ok(html.includes(`<strong>${sentence}</strong>我们`));
    assert.doesNotMatch(html, /\*\*/);
  }
  const preview = renderToStaticMarkup(React.createElement(ReactMarkdown, {
    remarkPlugins: markdownPreviewRemarkPlugins,
    rehypePlugins: markdownPreviewRehypePlugins,
  }, markdown));
  assert.ok(preview.includes(`<strong>${sentence}</strong>我们`));
});

test("renders CJK brackets next to prose while preserving nested emphasis", () => {
  assert.match(renderMarkdown("这是**「重要」**内容。"), /这是<strong>「重要」<\/strong>内容。/);
  assert.match(renderMarkdown("これは**テスト。**テスト"), /これは<strong>テスト。<\/strong>テスト/);
  assert.match(renderMarkdown("**outer *inner* text**"), /<strong>outer <em>inner<\/em> text<\/strong>/);
});

test("keeps CJK emphasis markers literal in code and escaped text", () => {
  const literal = "**需要。**即使";
  for (const markdown of [`\`${literal}\``, `\`\`\`\n${literal}\n\`\`\``, "\\*\\*需要。\\*\\*即使"]) {
    const html = renderMarkdown(markdown);
    assert.doesNotMatch(html, /<strong>/);
    assert.ok(html.includes(literal));
  }
});

test("opens non-file markdown links in a safe new tab", () => {
  const html = renderMarkdown("[docs](https://example.com/docs)");

  assert.match(
    html,
    /<a (?=[^>]*href="https:\/\/example\.com\/docs")(?=[^>]*target="_blank")(?=[^>]*rel="noopener noreferrer")[^>]*>docs<\/a>/,
  );
  assert.doesNotMatch(html, /\snode=/);
});

test("opens desktop app links like other external links (#1108)", () => {
  for (const props of [{}, { onOpenFile: undefined }]) {
    const html = renderMarkdown("[note](obsidian://open?vault=notes)", props);

    assert.match(
      html,
      /<a (?=[^>]*href="obsidian:\/\/open\?vault=notes")(?=[^>]*target="_blank")(?=[^>]*rel="noopener noreferrer")[^>]*>note<\/a>/,
    );
  }
});

test("keeps local file markdown links in the app", () => {
  const relativeHtml = renderMarkdown("[file](components/MarkdownBody.tsx)");
  const fileUrlHtml = renderMarkdown("[report](file:///home/me/project/report.html)");

  assert.match(relativeHtml, /<a href="components\/MarkdownBody\.tsx">file<\/a>/);
  assert.doesNotMatch(relativeHtml, /target=|rel=|\snode=/);
  assert.match(fileUrlHtml, /<a href="file:\/\/\/home\/me\/project\/report\.html">report<\/a>/);
  assert.doesNotMatch(fileUrlHtml, /target=|rel=|\snode=/);
});

test("keeps Windows drive report links in chat and user messages", () => {
  for (const keepLineBreaks of [false, true]) {
    for (const url of ["C:/reports/REPORT.md", "/C:/reports/REPORT.md", "d:/报告 one%20%2520.md:12:3#片段"]) {
      const normalized = `file:///${url.replace(/^\//, "")}`;
      const expected = renderMarkdown(`[report](<${normalized}>)`, { keepLineBreaks });
      assert.equal(renderMarkdown(`[report](<${url}>)`, { keepLineBreaks }), expected);
      assert.equal(renderMarkdown(`[report][ref]\n\n[ref]: <${url}>`, { keepLineBreaks }), expected);
      assert.match(expected, /href="file:\/\/\//);
      assert.doesNotMatch(expected, /target=|rel=/);
      const inert = renderMarkdown(`[report](<${url}>)`, { keepLineBreaks, onOpenFile: undefined });
      assert.match(inert, /<a href="" target="_blank" rel="noopener noreferrer">report<\/a>/);
    }
  }
});

test("keeps file URLs inert without an in-app file handler", () => {
  const html = renderMarkdown("[report](file:///home/me/project/report.html)", { onOpenFile: undefined });

  assert.match(html, /<a href="" target="_blank" rel="noopener noreferrer">report<\/a>/);
});

test("keeps single-tilde CJK numeric ranges literal instead of striking them", () => {
  const html = renderMarkdown("5~7U 保证金 × 100~200倍杠杆");

  assert.doesNotMatch(html, /<del>/);
  assert.match(html, /5~7U/);
  assert.match(html, /100~200倍/);
});

test("still renders double-tilde strikethrough", () => {
  const html = renderMarkdown("~~gone~~");

  assert.match(html, /<del>gone<\/del>/);
});

test("renders backslash-escaped backticks inside inline code", () => {
  const html = renderMarkdown("`AudioManager\\`1.cs`");

  assert.match(html, /<code[^>]*>AudioManager`1\.cs<\/code>/);
  assert.doesNotMatch(html, /<\/code>1\.cs`/);
});

test("renders LaTeX parenthesis delimiters as inline math", () => {
  const html = renderMarkdown(String.raw`射线为 \(r_c = K^{-1}p\)。`);

  assert.match(html, /class="katex"/);
  assert.match(html, /r_c/);
});

test("keeps prices and bold headings intact across a paragraph line break", () => {
  const html = renderMarkdown("**3. Membership — $20/mo (+tax)**\nOne free hour monthly. Waives the $6 activation fee.\n→ https://example.com/pricing");

  assert.match(html, /<strong>3\. Membership — \$20\/mo \(\+tax\)<\/strong>/);
  assert.match(html, /One free hour monthly\. Waives the \$6 activation fee\./);
  assert.match(html, /href="https:\/\/example\.com\/pricing"/);
  assert.doesNotMatch(html, /class="katex|\*\*/);
});

test("keeps adjacent amounts, ranges and decimals as currency", () => {
  for (const prices of ["$15+$15", "$20–$30", "$1,200.50 or $900.00", "**$20** and *$6*", "US$20 / CA$30"]) {
    const html = renderMarkdown(prices);
    assert.doesNotMatch(html, /class="katex/, prices);
    assert.equal((html.match(/\$/g) ?? []).length, 2, prices);
  }
});

test("does not let a price consume later math in the same paragraph", () => {
  const html = renderMarkdown("Pay $20 for the $x + 1$ option, or $30 for $2x + 3$.");

  assert.match(html, /Pay \$20 for the/);
  assert.match(html, /or \$30 for/);
  assert.equal((html.match(/class="katex"/g) ?? []).length, 2);
  assert.match(html, /<annotation encoding="application\/x-tex">x \+ 1<\/annotation>/);
  assert.match(html, /<annotation encoding="application\/x-tex">2x \+ 3<\/annotation>/);
});

test("retains single-dollar equations, numeric math, balanced padding and multiline math", () => {
  for (const math of ["$x + y$", "$2 + 2 = 4$", "$20$", "$ x + y $", "$x $", "$ x$", "$x$2", "$x +\ny$", "$$x + y$$"]) {
    const html = renderMarkdown(math);
    assert.match(html, /class="katex"/, math);
    assert.doesNotMatch(html, /katex-error/, math);
  }
});

test("file previews and minimap Markdown use the same currency-safe math rules", () => {
  const html = renderToStaticMarkup(React.createElement(ReactMarkdown, {
    remarkPlugins: markdownPreviewRemarkPlugins,
    rehypePlugins: markdownPreviewRehypePlugins,
  }, "**Price: $20/month**\nPlus a $6 fee. Formula: $2 + 2 = 4$."));
  assert.match(html, /<strong>Price: \$20\/month<\/strong>/);
  assert.match(html, /Plus a \$6 fee/);
  assert.equal((html.match(/class="katex"/g) ?? []).length, 1);
});

test("leaves escaped currency, code and link destinations intact", () => {
  const html = renderMarkdown("Prices: \\$20 and \\$6. Code: `$20 + $6`. [Price](https://example.com/$20/$6)");
  assert.doesNotMatch(html, /class="katex/);
  assert.match(html, /Prices: \$20 and \$6\./);
  assert.match(html, /<code[^>]*>\$20 \+ \$6<\/code>/);
  assert.match(html, /href="https:\/\/example\.com\/\$20\/\$6"/);
  const fenced = renderMarkdown("```text\n$20 + $6\n```");
  assert.doesNotMatch(fenced, /class="katex/);
});

test("currency text still passes through HTML and URL sanitization", () => {
  const html = renderMarkdown('$20 <img src="x" onerror="alert(1)"> $6 [click](javascript:alert(1))');
  assert.doesNotMatch(html, /onerror|javascript:|class="katex/);
  assert.match(html, /\$20/);
  assert.match(html, /\$6/);
});

test("renders paired LaTeX bracket delimiters as display math", () => {
  const html = renderMarkdown(String.raw`\[
P(\lambda)=o_b+\lambda r_b
\]`);
  const oneLineHtml = renderMarkdown(String.raw`\[P(\lambda)=o_b+\lambda r_b\]`);

  assert.match(html, /class="katex-display"/);
  assert.match(html, /lambda/);
  assert.match(oneLineHtml, /class="katex-display"/);
});

test("renders model-emitted bracket-only formula lines as display math", () => {
  const html = renderMarkdown(String.raw`平均一致性：

[ C(x) = \frac{2}{T(T-1)} \sum_{i<j} S(\hat{y}^{(i)}, \hat{y}^{(j)}) ]`);

  assert.match(html, /class="katex-display"/);
  assert.match(html, /\\sum/);
});

test("leaves an unmatched LaTeX bracket delimiter unchanged", () => {
  const markdown = String.raw`before
\[
x + y
after`;

  assert.equal(normalizeDisplayMath(markdown), markdown);
});

test("does not normalize LaTeX delimiters inside Markdown code", () => {
  const markdown = "    \\(indented\\)\n\n`code\n\\(inline\\)`\n\n```text\n\\[\nfenced\n\\]\n```";

  assert.equal(normalizeDisplayMath(markdown), markdown);
});

test("does not normalize LaTeX delimiters inside raw HTML code", () => {
  const markdown = "<code>\\(inline\\)</code>\n\n<pre>\n\\(block\\)\n</pre>";

  assert.equal(normalizeDisplayMath(markdown), markdown);
});

test("does not normalize escaped delimiters or link destinations", () => {
  const escaped = String.raw`Literal: \\(x+y\\).`;
  const link = String.raw`[docs](https://example.com/\(manual\))`;

  assert.equal(normalizeDisplayMath(escaped), escaped);
  assert.equal(normalizeDisplayMath(link), link);
});

test("previews completed Mermaid diagrams by default", () => {
  const html = renderMarkdown("```mermaid\ngraph TD\n  A --> B\n```");

  assert.match(html, /mermaid-block-loading/);
  assert.match(html, />Source</);
  assert.doesNotMatch(html, /A --&gt; B/);
});

test("keeps Mermaid source visible while the response is streaming", () => {
  const html = renderMarkdown("```mermaid\ngraph TD\n  A --> B\n```", { isStreaming: true });

  assert.doesNotMatch(html, /mermaid-block-loading/);
  assert.match(html, />Preview</);
  assert.match(html, /A --&gt; B/);
});

test("opens markdown images in the shared image preview", () => {
  const localHtml = renderMarkdown("![chart](docs/tmp/chart.png)");
  const remoteHtml = renderMarkdown("![logo](https://example.com/logo.png)");

  assert.match(localHtml, /<button[^>]+aria-label="Preview image: chart"[^>]*>/);
  assert.match(localHtml, /<img[^>]+src="\/api\/files\/home\/me\/project\/docs\/tmp\/chart\.png\?type=read"/);
  assert.match(localHtml, /<img[^>]+alt="chart"/);
  assert.match(remoteHtml, /<button[^>]+aria-label="Preview image: logo"[^>]*>/);
  assert.match(remoteHtml, /<img[^>]+src="https:\/\/example\.com\/logo\.png"/);
});

test("keeps linked markdown images as links instead of nested preview buttons", () => {
  const html = renderMarkdown("[![diagram](docs/tmp/diagram.png)](https://example.com/docs)");

  assert.match(
    html,
    /<a (?=[^>]*href="https:\/\/example\.com\/docs")(?=[^>]*target="_blank")[^>]*>/,
  );
  assert.match(html, /<img[^>]+alt="diagram"/);
  assert.doesNotMatch(html, /<a[^>]*>[\s\S]*<button/);
  assert.doesNotMatch(html, /<button[^>]*>[\s\S]*<\/a>/);
});

test("uses a generic preview label when a markdown image has no alt text", () => {
  const html = renderMarkdown("![](https://example.com/shot.png)");

  assert.match(html, /<button[^>]+aria-label="Preview image"[^>]*>/);
  assert.doesNotMatch(html, /Preview image:/);
});

test("plays a markdown audio or video file inline instead of showing a broken image", () => {
  const audioHtml = renderMarkdown("![take 2](out/take2.wav)");
  assert.match(
    audioHtml,
    /<audio (?=[^>]*controls="")(?=[^>]*preload="metadata")(?=[^>]*src="\/api\/files\/home\/me\/project\/out\/take2\.wav\?type=read")(?=[^>]*aria-label="take 2")[^>]*>/,
  );
  assert.doesNotMatch(audioHtml, /<img|<button|\snode=/);

  const videoHtml = renderMarkdown("![](https://example.com/clip.mp4?v=2)");
  assert.match(
    videoHtml,
    /<video (?=[^>]*controls="")(?=[^>]*playsInline="")(?=[^>]*preload="metadata")(?=[^>]*src="https:\/\/example\.com\/clip\.mp4\?v=2")[^>]*>/,
  );
  assert.doesNotMatch(videoHtml, /aria-label|<img|<button/);

  // A linked clip stays a plain player inside its link, as a linked image does.
  const linkedHtml = renderMarkdown("[![demo](out/demo.webm)](https://example.com/demo)");
  assert.match(linkedHtml, /<a [^>]*href="https:\/\/example\.com\/demo"[^>]*><video [^>]*src="\/api\/files\/home\/me\/project\/out\/demo\.webm\?type=read"[^>]*><\/video><\/a>/);

  // Images keep their preview.
  assert.match(renderMarkdown("![chart](out/chart.png)"), /<button[^>]+aria-label="Preview image: chart"/);
});

test("keeps CJK prose out of an autolinked URL", () => {
  const html = renderMarkdown("开 http://localhost:4321，或直接开 library/x.png。");

  assert.match(html, /<a (?=[^>]*href="http:\/\/localhost:4321")[^>]*>http:\/\/localhost:4321<\/a>/);
  assert.match(html, /<\/a>，或直接开 library\/x\.png。/);
  assert.doesNotMatch(html, /%EF%BC%8C/);
});

test("stops a bare autolink at trailing CJK punctuation", () => {
  const html = renderMarkdown("见 https://example.com/docs。");

  assert.match(html, /<a (?=[^>]*href="https:\/\/example\.com\/docs")[^>]*>https:\/\/example\.com\/docs<\/a>/);
  assert.match(html, /<\/a>。/);
});

test("leaves explicit markdown links, CJK paths and query strings intact", () => {
  const explicit = renderMarkdown("[文档](https://example.com/docs)，说明");
  assert.match(explicit, /<a (?=[^>]*href="https:\/\/example\.com\/docs")[^>]*>文档<\/a>/);
  assert.match(explicit, /<\/a>，说明/);

  const cjkPath = renderMarkdown("https://zh.wikipedia.org/wiki/中文条目");
  assert.match(cjkPath, /href="https:\/\/zh\.wikipedia\.org\/wiki\/%E4%B8%AD%E6%96%87%E6%9D%A1%E7%9B%AE"/);

  const query = renderMarkdown("https://a.com/p?a=1&b=2，后面");
  assert.match(query, /href="https:\/\/a\.com\/p\?a=1&amp;b=2"/);
  assert.match(query, /<\/a>，后面/);
});

test("turns line endings into <br> only when asked to keep line breaks", () => {
  assert.match(renderMarkdown("one\ntwo"), /<p>one\ntwo<\/p>/);
  assert.doesNotMatch(renderMarkdown("one\ntwo"), /<br/);

  for (const markdown of ["one\ntwo", "one\r\ntwo", "one\rtwo", "one   \t\n   two"]) {
    assert.match(renderMarkdown(markdown, { keepLineBreaks: true }), /<p>one<br\/>two<\/p>/);
  }
});

test("keeps typed line breaks in tight list items and headings", () => {
  const ordered = renderMarkdown("1. 看门狗的原理是（ ）\nA. 监控温度\nB. 计数器\n2. 下一题", { keepLineBreaks: true });
  const nested = renderMarkdown("- outer\n  more\n  - inner\n- next", { keepLineBreaks: true });
  const heading = renderMarkdown("Heading one\nheading two\n===", { keepLineBreaks: true });

  assert.match(ordered, /<li>看门狗的原理是（ ）<br\/>A\. 监控温度<br\/>B\. 计数器<\/li>/);
  assert.match(ordered, /<li>下一题<\/li>/);
  // The newline before a nested list separates blocks, so it must not become a <br>.
  assert.match(nested, /<li>outer<br\/>more\n<ul>\n<li>inner<\/li>/);
  assert.match(heading, /<h1>Heading one<br\/>heading two<\/h1>/);
  assert.doesNotMatch(renderMarkdown("- alpha\n\n- beta", { keepLineBreaks: true }), /<br/);
});

test("renders a hard break once when keeping line breaks", () => {
  // remark-rehype writes an mdast break as <br> plus "\n", which the user
  // bubble's pre-wrap paragraphs would show as a blank line.
  const html = renderMarkdown("trailing spaces  \nbackslash\\\nend", { keepLineBreaks: true });

  assert.match(html, /<p>trailing spaces<br\/>backslash<br\/>end<\/p>/);
});

test("leaves code and math line endings alone when keeping line breaks", () => {
  const code = renderMarkdown("```\nfirst\nsecond\n```", { keepLineBreaks: true });
  const math = renderMarkdown("$$\nx = 1\ny = 2\n$$", { keepLineBreaks: true });
  const emphasis = renderMarkdown("*one\ntwo* `a b`", { keepLineBreaks: true });

  assert.doesNotMatch(code, /<br/);
  assert.match(code, /first[\s\S]*\n[\s\S]*second/);
  assert.doesNotMatch(math, /<br/);
  assert.match(math, /<annotation encoding="application\/x-tex">x = 1\ny = 2<\/annotation>/);
  assert.match(emphasis, /<em>one<br\/>two<\/em>/);
});

test("display math gets a Copy button for its LaTeX source; inline math does not", () => {
  const copyButtons = (html) => (html.match(/markdown-math-copy/g) ?? []).length;
  const markdown = "$$\n\\frac{a}{b} < c\n$$\n\n```math\na^2\n```\n\nInline $x$ and $$y$$ stay plain.";
  for (const props of [{}, { onNavigateLink() {} }, { isStreaming: true }]) {
    const html = renderMarkdown(markdown, props);
    assert.equal(copyButtons(html), 2);
    assert.equal((html.match(/class="katex-display"/g) ?? []).length, 2);
    assert.doesNotMatch(html, /data-math-source/);
  }
  // The source is the Markdown's, kept before KaTeX writes its glyphs.
  const sources = [];
  renderToStaticMarkup(React.createElement(ReactMarkdown, {
    remarkPlugins: markdownRemarkPlugins,
    rehypePlugins: markdownRehypePlugins,
    components: {
      div({ node, children }) {
        sources.push(node.properties.dataMathSource);
        return React.createElement("div", null, children);
      },
    },
  }, markdown));
  assert.deepEqual(sources, ["\\frac{a}{b} < c", "a^2"]);
  // A half-streamed formula renders KaTeX's error text and still copies.
  assert.equal(copyButtons(renderMarkdown("$$\n\\frac{a", { isStreaming: true })), 1);
  // A user's own HTML cannot carry the attribute: the sanitizer drops it.
  assert.equal(copyButtons(renderMarkdown('<div data-math-source="x">hi</div>')), 0);
});

test("shows a user message's HTML as the text typed, like pi's TUI", () => {
  // #1407: the tag was parsed by rehype-raw and stripped by the sanitizer.
  const sample = '<TableOperator v-model="columns" :tableId="TABLE_ID_CONST.BUSINESS.${basic.businessModule.toUpperCase()}.Demo" :refresh="queryData" /> 咋更离谱呢，要不就去掉 ${basic.businessModule.toUpperCase()} 不要这个变量，直接拼后面部分';
  const escaped = sample.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  assert.equal(renderMarkdown(sample, { keepLineBreaks: true }), `<div class="markdown-body"><p>${escaped}</p></div>`);

  // Inline and block HTML, raw-text tags included, keep their characters and line breaks.
  assert.match(renderMarkdown("normal <kbd>Ctrl</kbd>\nline two", { keepLineBreaks: true }), /<p>normal &lt;kbd&gt;Ctrl&lt;\/kbd&gt;<br\/>line two<\/p>/);
  assert.match(renderMarkdown("Use a <textarea> here\nand a button", { keepLineBreaks: true }), /<p>Use a &lt;textarea&gt; here<br\/>and a button<\/p>/);
  assert.match(renderMarkdown("<div>\n<b>hi</b>\n</div>\n\nafter", { keepLineBreaks: true }), /<p>&lt;div&gt;<br\/>&lt;b&gt;hi&lt;\/b&gt;<br\/>&lt;\/div&gt;<\/p>\n<p>after<\/p>/);
  assert.match(renderMarkdown("- item <script>a()</script>\n- <!-- note -->", { keepLineBreaks: true }), /<li>item &lt;script&gt;a\(\)&lt;\/script&gt;<\/li>\n<li>&lt;!-- note --&gt;<\/li>/);
  assert.match(renderMarkdown("> <img src=x onerror=alert(1)>", { keepLineBreaks: true }), /<blockquote>\n<p>&lt;img src=x onerror=alert\(1\)&gt;<\/p>\n<\/blockquote>/);

  // Markdown around it still renders; code keeps its own text; assistant text keeps rendering HTML.
  const mixed = renderMarkdown("**bold** <u>x</u> [link](https://example.com) `<b>`\n\n```html\n<p>code</p>\n```", { keepLineBreaks: true });
  assert.match(mixed, /<strong>bold<\/strong> &lt;u&gt;x&lt;\/u&gt; <a href="https:\/\/example\.com"[^>]*>link<\/a> <code[^>]*>&lt;b&gt;<\/code>/);
  assert.match(mixed, /&lt;p&gt;code&lt;\/p&gt;/);
  assert.match(renderMarkdown("normal <kbd>Ctrl</kbd>"), /<kbd>Ctrl<\/kbd>/);
});
