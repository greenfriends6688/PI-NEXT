import type { ThinkingLevel } from "@earendil-works/pi-agent-core";
import { createAgentSessionFromServices, createAgentSessionServices, getAgentDir, initTheme, SessionManager, SettingsManager, Theme, type ModelRuntime } from "@earendil-works/pi-coding-agent";
import { KeybindingsManager as TuiKeybindingsManager, TUI_KEYBINDINGS } from "@earendil-works/pi-tui";
import { randomUUID } from "crypto";
import { existsSync, realpathSync, writeFileSync } from "fs";
import { resolve } from "path";
import { isDeepStrictEqual } from "util";
import { validateAgentImages } from "./image-attachments";
import { cwdMissingError } from "./missing-cwd";
import { invalidateModelsCache } from "./models-cache";
import { invalidateModelRuntimeWithExtensions } from "./model-runtime";
import { resolveVisibleModels, selectInitialModelScope } from "./model-scope";
import { findDeferredModel, findDeferredStartupModel, rememberProviderModels } from "./deferred-provider-models";
import { isBlockingExtensionUiRequest } from "./extension-ui-queue";
import {
  createProjectCommandBashExtension,
  createProjectCommandBashOperations,
  preferUserBashExtension,
} from "./project-command-env";
import { cacheSessionPath, catalogFirstMessage, getLatestModelChange, invalidateSessionListCache, readLatestSessionEntryId, resolveSessionPath } from "./session-reader";
import { computeLiveSessionTotalActiveMs } from "./session-timing";
import { getProjectTrustStatus, projectTrustReloadOptions } from "./project-trust";
import { notifySessionComplete } from "./web-push";
import { hasActiveSessionLivenessProvider } from "./session-liveness";
import type { SlashCommandInfo } from "@earendil-works/pi-coding-agent";
import type { AgentSessionLike, ExtensionUiContextLike, ToolInfo } from "./pi-types";
import type {
  ExtensionUiRequest,
  ExtensionUiResponse,
  ExtensionWidgetItem,
  SessionEntry,
  SessionInfo,
  SessionMessageEntry,
  SubagentSessionStatus,
} from "./types";
import { createHeadlessCustomUiTui, DEFAULT_CUSTOM_UI_COLUMNS, type HeadlessCustomUiTui } from "./custom-ui-terminal";
import {
  createSubagentExtension,
  preferPiWebSubagentExtension,
} from "./subagent-extension";
import {
  listSubagentProfiles,
  hasSubagentResourceSnapshot,
  readSubagentRun,
  readSubagentSessionResources,
  settleOrphanedSubagentStatus,
  subagentExtensionLoaderOptions,
  subagentToolOptions,
  SUBAGENT_CONTROL_TOOL_NAMES,
} from "./subagents";
import { createSubagentController, getLiveSubagentStatus, hasUnsettledSubagentRun } from "./subagent-runtime";
import { isBuiltInSubagentsEnabled } from "./subagent-settings";
import { resolveShellTools } from "./powershell-settings";
import { CHAT_ONLY_RESOURCE_LOADER_OPTIONS, contextFilesSystemPrompt } from "./chat-only";
import { createExactSystemPromptExtension } from "./exact-system-prompt";
import { createPiWebBuiltinExtensions, createSubagentCodemodeExtension, createSubagentMcpExtensions } from "./builtin-extensions";
import type { McpHost } from "./mcp-host";
import type { DebugMcpHost, DebugSessionLifecycle, DebugWrapperSnapshot } from "./debug-types";
import { mcpPromptPreparation, type McpCommandCandidate } from "./mcp-command";
import { createReadOnlyMcpPolicyExtension, createSubagentMcpPolicyExtension } from "./mcp-read-only-policy";
import { createSubagentSkillsBinding } from "./subagent-skills";
import { isNestedToolExecutionEvent } from "./agent-event-wire";
import { collectLiveAssistantNotices, readShowCacheMissNotices, withSessionPrices } from "./transcript-notices-server";
import {
  appendClearedSessionToolSelection,
  appendSessionToolSelection,
  readSessionToolSelection,
  validateSessionToolSelection,
} from "./session-tool-selection";

// ============================================================================
// Types
// ============================================================================

export interface AgentEvent {
  type: string;
  [key: string]: unknown;
}

type EventListener = (event: AgentEvent) => void;

/**
 * A prompt parked while a manual compaction runs. pi's SDK refuses prompts then
 * ("Cannot submit a prompt while compaction is in progress"), so the wrapper
 * holds the submission and flushes it FIFO at compaction end, as pi's TUI
 * `compactionQueuedMessages` does (interactive-mode.js).
 */
type ParkedPrompt = {
  message: string;
  images?: Array<{ type: "image"; data: string; mimeType: string }>;
  /** The composer's steer / followUp; undefined: sent as a fresh prompt, parked as steer (the TUI's Enter). */
  streamingBehavior?: "steer" | "followUp";
  /** Settles the admission's `pendingPromptCount` (idempotent): on delivery, recall, Stop or a failed send. */
  settle: () => void;
  /** A flush is waiting for its admission; it stays a queue row (Recall, Stop) until then. */
  delivering?: boolean;
};

/** What Recall and Stop hand back to the composer: the texts by queue, and the parked prompts' images. */
type RecalledPrompts = {
  steering: string[];
  followUp: string[];
  images?: Array<{ data: string; mimeType: string }>;
};
/** `sessionName`: the live session's own title (its newest `session_info`), read without a disk scan. */
type AgentRunCompleteListener = (sessionId: string, sessionName: string | undefined) => void;

type PendingUiResponse = {
  resolve: (response: ExtensionUiResponse) => void;
  cancel: () => void;
};

type CustomUiComponent = {
  render: (width: number) => string[];
  handleInput?: (data: string) => void;
  dispose?: () => void;
  invalidate?: () => void;
};

type ExtensionWidgetComponent = {
  render: (width: number) => unknown;
  dispose?: () => void;
};

type ExtensionWidgetFactory = (tui: HeadlessCustomUiTui, theme: Theme) => unknown;

type ActiveExtensionWidget = {
  key: string;
  component: ExtensionWidgetComponent;
  placement: "aboveEditor" | "belowEditor";
  generation: number;
  clearEmitted: boolean;
  rendered: boolean;
};

type ActiveCustomUi = {
  component: CustomUiComponent;
  width: number;
  resolve: (value: unknown) => void;
  settled: boolean;
};

type ExtensionUiRequestBody = Record<string, unknown> & {
  method: ExtensionUiRequest["method"];
  timeout?: number;
  expiresAt?: number;
};

type ExtensionCommandContextActionsLike = {
  waitForIdle: () => Promise<void>;
  newSession: () => Promise<{ cancelled: boolean }>;
  fork: () => Promise<{ cancelled: boolean }>;
  navigateTree: (targetId: string, options?: { summarize?: boolean }) => Promise<{ cancelled: boolean }>;
  switchSession: () => Promise<{ cancelled: boolean }>;
  reload: () => Promise<void>;
};

// `debugSnapshot` is optional: a host built before a hot reload lacks it.
type WrapperMcpHost = Pick<McpHost, "prepareForPrompt" | "dispose"> & Partial<Pick<McpHost, "debugSnapshot">>;

type AgentSessionWrapperOptions = {
  exactSystemPrompt?: () => string;
  chatOnly?: boolean;
  onAgentRunComplete?: AgentRunCompleteListener;
  suppressCompletionNotifications?: boolean;
  /** Connects the session's MCP servers before a prompt starts a run, and lets go of them when it closes (lib/mcp-host.ts). */
  mcpHost?: WrapperMcpHost;
  /** Chat only: the extension-provided model the session wanted, named when a prompt finds no model. */
  chatOnlyExtensionModel?: { provider: string; id: string };
};

/**
 * Chat only loads no extensions, so a provider one registers is missing from its runtime (#804).
 * Said instead of "Model not found", or pi's "No API key found" for a session left without a model.
 */
function chatOnlyExtensionModelError(provider: string, modelId: string): Error {
  return new Error(
    `${provider}/${modelId} is provided by an extension, and Chat only loads no extensions. Choose another model or tool preset.`,
  );
}

export const MCP_WAIT_STOPPED_MESSAGE = "Stopped while MCP servers were connecting; the message was not sent.";

const IDLE_RESET_EVENT_TYPES = new Set([
  "agent_end",
  "agent_settled",
  "auto_compaction_end",
  "compaction_end",
]);

const DEFAULT_SESSION_IDLE_TIMEOUT_MS = 10 * 60 * 1000;

/**
 * Resolves the PI_WEB_IDLE_TIMEOUT_MS environment variable into a session idle
 * timeout in milliseconds. An unset/blank value returns the 10-minute default,
 * `0` disables idle shutdown, and positive values up to Node's timer limit
 * (2147483647 ms) are used as-is. Invalid or out-of-range values fall back to
 * the default with a console warning.
 * @param rawValue Value to parse; defaults to the environment variable.
 */
export function resolveSessionIdleTimeoutMs(
  rawValue: string | undefined = process.env.PI_WEB_IDLE_TIMEOUT_MS,
): number {
  if (rawValue !== undefined && rawValue.trim() !== "") {
    const parsed = Number(rawValue);
    if (Number.isFinite(parsed) && parsed >= 0 && parsed <= 2_147_483_647) return parsed;
    console.warn(`[pi-web] invalid PI_WEB_IDLE_TIMEOUT_MS "${rawValue}", falling back to 10 minutes`);
  }
  return DEFAULT_SESSION_IDLE_TIMEOUT_MS;
}

/** Resolved once: the debug panel reads it rather than resolving the variable again, which warns. */
export const SESSION_IDLE_TIMEOUT_MS = resolveSessionIdleTimeoutMs();

const DEFAULT_SESSION_SHUTDOWN_DEADLINE_MS = 5_000;

/**
 * Resolves the PI_WEB_SHUTDOWN_DEADLINE_MS environment variable into the time
 * extensions get to handle `session_shutdown` before the wrapper disposes the
 * SDK session anyway. An unset/blank value returns the 5-second default, and
 * positive values up to Node's timer limit (2147483647 ms) are used as-is.
 * `0`, invalid and out-of-range values fall back to the default with a console
 * warning: shutdown always has a deadline.
 * @param rawValue Value to parse; defaults to the environment variable.
 */
export function resolveSessionShutdownDeadlineMs(
  rawValue: string | undefined = process.env.PI_WEB_SHUTDOWN_DEADLINE_MS,
): number {
  if (rawValue !== undefined && rawValue.trim() !== "") {
    const parsed = Number(rawValue);
    if (Number.isFinite(parsed) && parsed > 0 && parsed <= 2_147_483_647) return parsed;
    console.warn(`[pi-web] invalid PI_WEB_SHUTDOWN_DEADLINE_MS "${rawValue}", falling back to 5 seconds`);
  }
  return DEFAULT_SESSION_SHUTDOWN_DEADLINE_MS;
}

const SESSION_SHUTDOWN_DEADLINE_MS = resolveSessionShutdownDeadlineMs();

/** Bounds `set_model`'s offline provider refresh, as pi's model selector bounds its own. */
const MODEL_REFRESH_TIMEOUT_MS = 15_000;

const SESSION_REPLACEMENT_COMMAND_TYPES = new Set(["fork", "clone"]);
// pi writes a session file at the first user message, so a session with no
// conversation on disk has nothing to copy from yet.
const UNSAVED_SESSION_FORK_ERROR =
  "This session has not been saved yet. Send a message before forking it.";
const COMMANDS_ALLOWED_DURING_SESSION_REPLACEMENT = new Set([
  "get_state",
  "get_session_stats",
  "get_last_assistant_text",
  "get_tools",
  "get_commands",
  "extension_ui_response",
  "extension_ui_input",
]);

export interface RpcSessionStartOptions {
  toolNames?: string[];
  initialModel?: { provider: string; modelId: string };
  allowInitialModelFallback?: boolean;
  thinkingLevel?: ThinkingLevel;
}

const CODING_TOOL_NAMES = ["read", "bash", "powershell", "edit", "write", "grep", "find", "ls"];
const THINKING_LEVEL_NAMES = new Set<ThinkingLevel>(["off", "minimal", "low", "medium", "high", "xhigh", "max"]);
// The SDK's DEFAULT_THINKING_LEVEL (dist/core/defaults.js), which it does not export.
const SDK_DEFAULT_THINKING_LEVEL: ThinkingLevel = "medium";

// Extensions require a complete Theme, while the web UI applies its own styling.
class PlainTextTheme extends Theme {
  constructor() {
    super(
      { muted: "", text: "", thinkingXhigh: "", searchMatchText: "" } as ConstructorParameters<typeof Theme>[0],
      { selectedBg: "" } as ConstructorParameters<typeof Theme>[1],
      "truecolor",
    );
  }

  override fg(...[, text]: Parameters<Theme["fg"]>): string { return text; }
  override bg(...[, text]: Parameters<Theme["bg"]>): string { return text; }
  override bold(text: string): string { return text; }
  override italic(text: string): string { return text; }
  override underline(text: string): string { return text; }
  override inverse(text: string): string { return text; }
  override strikethrough(text: string): string { return text; }
  override getFgAnsi(): string { return ""; }
  override getBgAnsi(): string { return ""; }
  override getThinkingBorderColor(): (text: string) => string {
    return (text) => text;
  }
  override getBashModeBorderColor(): (text: string) => string { return (text) => text; }
}

const PLAIN_TEXT_THEME = new PlainTextTheme();
const CUSTOM_UI_KEYBINDINGS = new TuiKeybindingsManager(TUI_KEYBINDINGS);

// Tools that belong to the session, not to a branch of it: the ones that reach other tools,
// and pi-web's subagent tools, which the built-in subagent setting switches on for the whole
// session. Navigation keeps them although the target branch was recorded without them.
const SESSION_TOOL_NAMES = new Set<string>(["codemode", "tool_search", ...SUBAGENT_CONTROL_TOOL_NAMES]);

/**
 * The active tools for a coding tool selection. The selection replaces only the coding
 * tools: every other tool named in `carry` that is still registered and not withdrawn stays
 * active, so a tool an extension, `tool_search`, or `defaultTools` activated survives, and a
 * tool one switched off stays off. Nothing else is added: pi itself activates the extension
 * tools it registers (all of them when it builds or reloads a session, then each new one), so
 * `carry` already holds them. An empty selection is Chat only.
 */
export function resolveActiveToolNames(
  session: AgentSessionLike,
  requested: readonly string[],
  carry: readonly string[],
): string[] {
  if (requested.length === 0) return [];

  const codingToolNames = new Set(CODING_TOOL_NAMES);
  const registered = new Map(session.getAllTools().map((tool) => [tool.name, tool]));
  const selectedToolNames = resolveShellTools(
    requested.filter((name) => codingToolNames.has(name)),
    session.settingsManager.getDefaultTools(),
  );
  const carriedToolNames = carry.filter((name) => {
    const tool = registered.get(name);
    return tool !== undefined && !codingToolNames.has(name) && tool.exposure !== "hidden";
  });

  return [...new Set([...selectedToolNames, ...carriedToolNames])];
}

/** pi's "Cannot submit a prompt while compaction is in progress" rejection. */
function isCompactionInProgressError(error: unknown): boolean {
  return error instanceof Error && /compaction is in progress/i.test(error.message);
}

// ============================================================================
// AgentSessionWrapper
// Wraps AgentSession with the same interface the rest of the app expects
// ============================================================================

export class AgentSessionWrapper {
  // A Set, not an array: an SSE stream unsubscribes from inside emit() when it
  // closes on session_shutdown, and splicing an array mid-iteration made the
  // next stream miss that same event.
  private listeners = new Set<EventListener>();
  private activeToolEvents = new Map<string, AgentEvent>();
  private pendingUiResponses = new Map<string, PendingUiResponse>();
  private pendingUiRequests = new Map<string, AgentEvent>();
  private activeCustomUis = new Map<string, ActiveCustomUi>();
  private extensionUiAbortController = new AbortController();
  private extensionStatuses = new Map<string, string>();
  private extensionWidgets = new Map<string, ExtensionWidgetItem>();
  private activeExtensionWidgets = new Map<string, ActiveExtensionWidget>();
  private extensionWidgetGenerations = new Map<string, number>();
  private extensionWidgetsResetting = false;
  private pendingPromptCount = 0;
  // Prompts waiting for the running compaction to finish (ParkedPrompt above).
  private parkedDuringCompaction: ParkedPrompt[] = [];
  private activeMutatingCommands = 0;
  private sessionReplacement: "fork" | "clone" | null = null;
  private agentRunNeedsCompletion = false;
  // Whether the last run ended because it was stopped (pi 1.1's `agent_settled.aborted`), not finished.
  private lastRunAborted = false;
  private promptAdmissionTail: Promise<void> = Promise.resolve();
  private extensionsBound = false;
  private extensionBindingPromise: Promise<void> | null = null;
  private extensionBindingError: unknown = null;
  private readonly exactSystemPrompt?: () => string;
  private readonly chatOnly: boolean;
  private readonly onAgentRunComplete?: AgentRunCompleteListener;
  private readonly suppressCompletionNotifications: boolean;
  private readonly mcpHost?: WrapperMcpHost;
  private readonly chatOnlyExtensionModel?: { provider: string; id: string };
  private mcpHostDisposed = false;
  // The MCP wait of the prompt being admitted; Stop ends it.
  private mcpPromptWait: { controller: AbortController; done: Promise<void> } | null = null;
  private unsubscribe: (() => void) | null = null;
  private idleTimer: ReturnType<typeof setTimeout> | null = null;
  private onDestroyCallback: (() => void) | null = null;
  private shutdownPromise: Promise<void> | null = null;
  private sessionShutdownEmitted = false;
  private forceShutdownOnIdle = false;
  // The armed idle timer is the forced cleanup Stop scheduled.
  private forcedIdleTimerArmed = false;
  private _alive = true;
  private resolveDisposed: () => void = () => {};
  private readonly disposed = new Promise<void>((resolve) => { this.resolveDisposed = resolve; });
  // Set when shutdown() starts. The SDK session stays usable until destroy(),
  // but lookups must treat the wrapper as gone from this point on.
  private closing = false;
  // Bookkeeping for the debug panel (getDebugSnapshot()): times and type names only, written
  // beside the code they describe and read nowhere else.
  private readonly createdAt = Date.now();
  private startedAt: number | null = null;
  private closingAt: number | null = null;
  // When the armed idle timer fires; idleTimer itself is never set back to null.
  private idleDeadlineAt: number | null = null;
  private idleLastResetAt: number | null = null;
  private lastEventType: string | null = null;
  private lastEventAt: number | null = null;
  private lastCommandType: string | null = null;
  private lastCommandAt: number | null = null;

  constructor(
    public readonly inner: AgentSessionLike,
    options: AgentSessionWrapperOptions = {},
  ) {
    this.exactSystemPrompt = options.exactSystemPrompt;
    this.chatOnly = options.chatOnly ?? false;
    this.onAgentRunComplete = options.onAgentRunComplete;
    this.suppressCompletionNotifications = options.suppressCompletionNotifications ?? false;
    this.mcpHost = options.mcpHost;
    this.chatOnlyExtensionModel = options.chatOnlyExtensionModel;
  }

  get sessionId(): string {
    return this.inner.sessionId;
  }

  get sessionFile(): string {
    return this.inner.sessionFile ?? "";
  }

  get cwd(): string {
    return this.inner.sessionManager.getCwd();
  }

  get streamingMessage() {
    return this.inner.agent.state?.streamingMessage;
  }

  get isStreaming(): boolean {
    return this.inner.isStreaming;
  }

  /**
   * False from the moment shutdown() or destroy() begins, not only once the SDK
   * session is disposed: extensions may take up to the shutdown deadline to
   * handle session_shutdown, and a prompt routed here meanwhile would be lost.
   */
  isAlive(): boolean {
    return this._alive && !this.closing;
  }

  isRunning(): boolean {
    return this._alive && (this.pendingPromptCount > 0 || this.inner.isStreaming || this.inner.isCompacting || this.inner.isBashRunning);
  }

  /**
   * True while an extension's blocking dialog is unanswered: select, confirm,
   * input, editor, or a custom overlay still open. The run is parked on a promise
   * only the user can settle, so the sidebar shows awaiting input rather than the
   * running spinner. Never true for an idle session: a custom overlay that
   * outlives its turn is not a parked run.
   */
  isAwaitingInput(): boolean {
    if (!this.isRunning()) return false;
    for (const request of this.pendingUiRequests.values()) {
      if (isBlockingExtensionUiRequest(request as unknown as ExtensionUiRequest)) return true;
    }
    return false;
  }

  /**
   * A page that has this session selected renews it (POST /api/agent/[id]/lease): the idle
   * countdown starts over at the full timeout, so a closed tab's session is reaped one idle
   * timeout after its last renewal. Not a command: lastCommand and the mutating count stay as
   * they are. A closing wrapper gets no new timer, and resetIdleTimer() leaves Stop's forced
   * deadline where it is.
   */
  renewIdleTimer(): void {
    if (!this.isAlive()) return;
    this.resetIdleTimer();
  }

  /**
   * Drop this idle wrapper when the on-disk JSONL has an entry the in-memory
   * index never saw (another pi process appended). Rechecks isRunning() so a
   * prompt that started during the probe cannot be disposed.
   */
  evictIfDiskAhead(): boolean {
    if (!this.isAlive() || this.isRunning()) return false;
    const diskLatestId = readLatestSessionEntryId(this.sessionFile);
    if (!diskLatestId || this.inner.sessionManager.getEntry(diskLatestId)) return false;
    if (this.isRunning()) return false;
    this.destroy();
    invalidateSessionListCache();
    return true;
  }

  isChatOnly(): boolean {
    return this.chatOnly;
  }

  hasSuppressedCompletionNotifications(): boolean {
    return this.suppressCompletionNotifications;
  }

  /**
   * What the debug panel shows of this wrapper: its fields and the SDK's plain getters, as
   * counts, flags and times. Never send(): that moves the idle timer, waits for extensions and
   * renders the system prompt.
   */
  getDebugSnapshot(): DebugWrapperSnapshot {
    const inner = this.inner;
    return {
      sessionId: this.sessionId,
      state: this.isAlive() ? "alive" : "closing",
      stale: false,
      subagent: this.suppressCompletionNotifications,
      chatOnly: this.chatOnly,
      createdAt: this.createdAt,
      startedAt: this.startedAt,
      closingAt: this.closingAt,
      extensions: this.extensionBindingError !== null
        ? "failed"
        : this.extensionsBound
          ? "bound"
          : this.extensionBindingPromise ? "binding" : "none",
      run: {
        running: this.isRunning(),
        streaming: inner.isStreaming === true,
        promptRunning: this.pendingPromptCount > 0,
        // The running prompt holds one count until its run ends; a queued steer or follow-up
        // drops its own at once and reads in queuedMessages instead.
        pendingPrompts: Math.max(0, this.pendingPromptCount - 1),
        bashRunning: inner.isBashRunning === true,
        compacting: inner.isCompacting === true,
        retrying: inner.isRetrying === true,
        queuedMessages: typeof inner.pendingMessageCount === "number" ? inner.pendingMessageCount : 0,
        waitingForMcp: this.mcpPromptWait !== null,
        runningTools: this.activeToolEvents.size,
        mutatingCommands: this.activeMutatingCommands,
        replacement: this.sessionReplacement,
      },
      idle: {
        timeoutMs: SESSION_IDLE_TIMEOUT_MS,
        nextCheckAt: this.idleDeadlineAt,
        lastResetAt: this.idleLastResetAt,
        forcedByStop: this.forceShutdownOnIdle && this.idleDeadlineAt !== null,
      },
      awaitingInput: this.isAwaitingInput(),
      pendingUiRequests: this.pendingUiRequests.size,
      customUis: this.activeCustomUis.size,
      eventListeners: this.listeners.size,
      lastEvent: this.lastEventType !== null && this.lastEventAt !== null
        ? { type: this.lastEventType, at: this.lastEventAt }
        : null,
      lastCommand: this.lastCommandType !== null && this.lastCommandAt !== null
        ? { type: this.lastCommandType, at: this.lastCommandAt }
        : null,
    };
  }

  /** The MCP host's state for the debug panel; null without a host (Chat only, MCP unavailable). */
  getMcpDebugSnapshot(): DebugMcpHost | null {
    return this.mcpHost?.debugSnapshot?.() ?? null;
  }

  start(): void {
    this.startedAt = Date.now();
    this.unsubscribe = this.inner.subscribe((event: AgentEvent) => {
      this.lastEventType = typeof event.type === "string" ? event.type : null;
      this.lastEventAt = Date.now();
      if (event.type === "agent_start") {
        this.agentRunNeedsCompletion = true;
        this.lastRunAborted = false;
      }
      if (event.type === "agent_settled") this.lastRunAborted = event.aborted === true;
      if (event.type === "agent_end") {
        invalidateSessionListCache();
        // Every tool call of the run has finished; nothing is left to replay.
        this.activeToolEvents.clear();
      }
      // A name from setSessionName(), an extension's included: a title generated
      // in the background lands after the run's agent_end, a command's with no
      // run at all, and the sidebar would keep the old one (#1237).
      if (event.type === "session_info_changed") invalidateSessionListCache();
      this.trackActiveToolEvent(event);
      if (IDLE_RESET_EVENT_TYPES.has(event.type)) this.resetIdleTimer();
      if (event.type === "compaction_end") {
        // Prompts parked while compaction ran go out now, FIFO, whatever its outcome (as the TUI).
        this.flushParkedPrompts();
      }
      this.emit(
        event.type === "message_end" ? this.withTranscriptNotices(event)
          : event.type === "agent_settled" ? this.withSubagentsActive(event)
            : event,
      );
      if (event.type === "agent_settled") this.notifyAgentRunCompleteIfIdle();
    });
    this.resetIdleTimer();
  }

  /**
   * An assistant `message_end` with the notices pi's TUI shows under
   * `showCacheMissNotices` (#1265), as `transcriptNotices` beside the message.
   * The message itself is left alone: pi writes that object to the file.
   */
  private withTranscriptNotices(event: AgentEvent): AgentEvent {
    const message = event.message as { role?: unknown } | undefined;
    if (this.listeners.size === 0 || message?.role !== "assistant") return event;
    try {
      const manager = this.inner.sessionManager;
      if (!readShowCacheMissNotices(manager.getCwd())) return event;
      const entries = manager.getEntries() as unknown as SessionEntry[];
      const notices = collectLiveAssistantNotices(
        entries,
        manager.getBranch() as unknown as SessionEntry[],
        message,
        withSessionPrices(entries, this.inner.modelRuntime),
      );
      return notices.length > 0 ? { ...event, transcriptNotices: notices } : event;
    } catch (error) {
      console.warn("[pi-web] transcript notices failed:", error instanceof Error ? error.message : error);
      return event;
    }
  }

  /**
   * Keep the latest start or update of each running tool call for onEvent() to
   * replay. Calls a tool makes itself (a codemode script's, which carry
   * `parentToolCallId`) are left out: a reconnecting client would show each as a
   * top-level tool, and the parent's own update already reports them. A nested
   * end can still arrive after its parent's, and is ignored like the rest.
   */
  private trackActiveToolEvent(event: AgentEvent): void {
    const toolCallId = event.toolCallId;
    if (typeof toolCallId !== "string" || isNestedToolExecutionEvent(event)) return;
    if (event.type === "tool_execution_start" || event.type === "tool_execution_update") {
      this.activeToolEvents.set(toolCallId, event);
    } else if (event.type === "tool_execution_end") {
      this.activeToolEvents.delete(toolCallId);
      const nestedPrefix = `${toolCallId}/`;
      for (const id of this.activeToolEvents.keys()) {
        if (id.startsWith(nestedPrefix)) this.activeToolEvents.delete(id);
      }
    }
  }

  private notifyAgentRunCompleteIfIdle(): void {
    if (!this.agentRunNeedsCompletion || this.isRunning()) return;
    this.agentRunNeedsCompletion = false;
    // A stopped run did not finish a task, as pi's own status reporting has it: nothing to announce.
    if (this.suppressCompletionNotifications || this.lastRunAborted) return;
    // A subagent of this session is still at work: each report starts a run here, and the run
    // after the last one is the end of the task (#1434).
    if (hasUnsettledSubagentRun(this.sessionId)) return;
    try {
      this.onAgentRunComplete?.(this.sessionId, this.inner.sessionManager.getSessionName());
    } catch (error) {
      console.error("[pi-web] completion listener failed:", error instanceof Error ? error.message : error);
    }
  }

  /**
   * `prompt_done`, saying `aborted` when the prompt's run was stopped rather than finished, and
   * `subagentsActive` while a subagent under this session can still start another run here.
   */
  private promptDoneEvent(): AgentEvent {
    return this.withSubagentsActive({ type: "prompt_done", ...(this.lastRunAborted ? { aborted: true } : {}) });
  }

  /** The end of a run of this session's, marked when its subagents keep the task going: no chime yet. */
  private withSubagentsActive(event: AgentEvent): AgentEvent {
    return hasUnsettledSubagentRun(this.sessionId) ? { ...event, subagentsActive: true } : event;
  }

  /** Parked prompts as queue rows: a plain one is a steer, as the TUI parks Enter during compaction. */
  private parkedQueueMessages(entries: readonly ParkedPrompt[]): { steering: string[]; followUp: string[] } {
    const steering: string[] = [];
    const followUp: string[] = [];
    for (const entry of entries) {
      (entry.streamingBehavior === "followUp" ? followUp : steering).push(entry.message);
    }
    return { steering, followUp };
  }

  /** pi's own queue plus the prompts parked during compaction, as the TUI's `getAllQueuedMessages()`. */
  private mergedQueuedMessages(): { steering: string[]; followUp: string[] } {
    const parked = this.parkedQueueMessages(this.parkedDuringCompaction);
    return {
      steering: [...this.inner.getSteeringMessages(), ...parked.steering],
      followUp: [...this.inner.getFollowUpMessages(), ...parked.followUp],
    };
  }

  private emitQueueUpdate(): void {
    this.emit({ type: "queue_update", ...this.mergedQueuedMessages() });
  }

  private parkDuringCompaction(entry: ParkedPrompt): void {
    this.parkedDuringCompaction.push(entry);
    this.emitQueueUpdate();
  }

  /**
   * Take every parked prompt back (Recall, Stop), those a flush has not handed to
   * the SDK yet included: their admissions settle, the texts and images return to
   * the composer.
   */
  private recallParkedPrompts(): RecalledPrompts {
    const parked = this.parkedDuringCompaction;
    if (parked.length === 0) return { steering: [], followUp: [] };
    this.parkedDuringCompaction = [];
    for (const entry of parked) entry.settle();
    this.emitQueueUpdate();
    // A plain prompt's client waits for prompt_done; nothing ran.
    if (parked.some((entry) => entry.streamingBehavior === undefined)) this.emit({ type: "prompt_done", aborted: true });
    const images = parked.flatMap((entry) => entry.images ?? []).map(({ data, mimeType }) => ({ data, mimeType }));
    return { ...this.parkedQueueMessages(parked), ...(images.length ? { images } : {}) };
  }

  /**
   * Deliver the prompts parked while compaction ran, FIFO: pi's TUI
   * `flushCompactionQueue()` in the wrapper. Each goes through the prompt
   * admission chain like any prompt, so the SDK decides start-or-join for one
   * submission at a time and a prompt sent after compaction_end queues behind
   * them. Each carries a `streamingBehavior` (a plain one as steer), so the
   * first starts a run when idle and the rest join it. An entry stays listed
   * until its delivery holds admission, so Recall and Stop still take it back.
   */
  private flushParkedPrompts(): void {
    for (const entry of this.parkedDuringCompaction) {
      if (entry.delivering) continue;
      entry.delivering = true;
      void this.deliverParkedPrompt(entry);
    }
  }

  private async deliverParkedPrompt(entry: ParkedPrompt): Promise<void> {
    const releaseAdmission = await this.acquirePromptAdmission();
    entry.delivering = false;
    const index = this.parkedDuringCompaction.indexOf(entry);
    if (index === -1) {
      // Recalled (Recall, Stop) while it waited.
      releaseAdmission();
      return;
    }
    this.parkedDuringCompaction.splice(index, 1);
    this.emitQueueUpdate();
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      releaseAdmission();
    };
    let disposition: "handled" | "queued" | "started" | undefined;
    let failure: unknown;
    try {
      await this.inner.prompt(entry.message, {
        ...(entry.images?.length ? { images: entry.images } : {}),
        source: "rpc",
        streamingBehavior: entry.streamingBehavior ?? "steer",
        preflightResult: (result) => {
          disposition = result;
          release();
        },
      });
    } catch (error) {
      failure = error;
    }
    release();
    if (failure !== undefined && disposition === undefined && isCompactionInProgressError(failure)) {
      // Another compaction started first: wait for that one's end.
      this.parkDuringCompaction(entry);
      return;
    }
    entry.settle();
    if (failure !== undefined) {
      // Refused unsent: keep it as a queue row for Recall or the next compaction end, as the TUI's restoreQueue().
      if (disposition === undefined) this.parkDuringCompaction(entry);
      this.emit({
        type: "prompt_error",
        errorMessage: failure instanceof Error ? failure.message : String(failure),
      });
    }
    // The client of a plain prompt waits for prompt_done; the delivery that started
    // the run sends it when that run ends, one that joined a run rides that run's.
    if (disposition === "started" || (disposition !== "queued" && entry.streamingBehavior === undefined)) {
      this.emit(this.promptDoneEvent());
    }
  }

  beginExtensionBinding(): void {
    void this.ensureExtensionsBound().catch((err) => {
      console.error("[pi-web] failed to dispatch session_start to extensions:", err instanceof Error ? err.message : err);
    });
  }

  async waitUntilReady(): Promise<void> {
    await this.waitForExtensionsBound();
  }

  /**
   * A subagent run prompts the SDK session directly (`lib/subagent-runtime.ts`), past `send()`:
   * connect the session's MCP servers first, as a sent prompt does, once session_start has bound
   * the host. Stop (`abort`) ends the wait as it ends a sent prompt's, and so does `signal`.
   * Resolves whether the run may start.
   */
  async prepareMcpForRun(signal: AbortSignal): Promise<boolean> {
    const mcpHost = this.mcpHost;
    if (!mcpHost || this.inner.isStreaming) return !signal.aborted;
    const controller = new AbortController();
    const stop = () => controller.abort();
    if (signal.aborted) stop();
    signal.addEventListener("abort", stop, { once: true });
    // Registered before the binding is awaited, so a Stop meanwhile already ends it.
    const waited = (async () => {
      await this.waitForExtensionsBound();
      if (!controller.signal.aborted) await mcpHost.prepareForPrompt(controller.signal);
    })().catch((error: unknown) => {
      console.error("[pi-web] MCP servers could not be prepared:", error instanceof Error ? error.message : error);
    });
    const wait = { controller, done: waited };
    this.mcpPromptWait = wait;
    try {
      await waited;
    } finally {
      signal.removeEventListener("abort", stop);
      if (this.mcpPromptWait === wait) this.mcpPromptWait = null;
    }
    return !controller.signal.aborted;
  }

  private ensureExtensionsBound(): Promise<void> {
    if (this.extensionsBound) return Promise.resolve();
    if (this.extensionBindingPromise) return this.extensionBindingPromise;

    this.extensionBindingError = null;
    this.extensionBindingPromise = (async () => {
      if (!this._alive) return;
      const uiContext = this.createExtensionUiContext();
      if (typeof this.inner.bindExtensions === "function") {
        const bindExtensions = this.inner.bindExtensions as (bindings: {
          uiContext?: ExtensionUiContextLike;
          mode?: "rpc";
          commandContextActions?: ExtensionCommandContextActionsLike;
          shutdownHandler?: () => void;
          onError?: (error: { extensionPath: string; event: string; error: string }) => void;
        }) => Promise<void>;
        await bindExtensions.call(this.inner, {
          uiContext,
          mode: "rpc",
          commandContextActions: this.createExtensionCommandContextActions(),
          shutdownHandler: () => this.emit({
            type: "extension_ui_request",
            id: randomUUID(),
            method: "notify",
            notifyType: "warning",
            message: "Extension requested shutdown, but shutdown is not supported in Pi Web.",
          } as ExtensionUiRequest as AgentEvent),
          onError: (error) => this.emit({
            type: "extension_error",
            extensionPath: error.extensionPath,
            event: error.event,
            error: error.error,
          }),
        });
      } else {
        this.inner.extensionRunner.setUIContext?.(uiContext, "rpc");
      }
      this.extensionsBound = true;
      console.log(`[pi-web] session_start dispatched to extensions for session ${this.inner.sessionId}`);
    })().catch((err) => {
      this.extensionBindingError = err;
      throw err;
    });

    return this.extensionBindingPromise;
  }

  private async waitForExtensionsBound(): Promise<void> {
    try {
      if (this.extensionBindingPromise) await this.extensionBindingPromise;
    } catch (err) {
      throw err instanceof Error ? err : new Error(String(err));
    }
    if (this.extensionBindingError) {
      throw this.extensionBindingError instanceof Error
        ? this.extensionBindingError
        : new Error(String(this.extensionBindingError));
    }
  }

  /** The session's extension commands as pi looks them up: by invocation name, with the extension's path. */
  private extensionCommandCandidates(): McpCommandCandidate[] {
    try {
      return this.inner.extensionRunner.getRegisteredCommands().map((command) => ({
        name: command.invocationName,
        sourceInfo: command.sourceInfo,
      }));
    } catch {
      // Unreadable: treat the prompt as one that may start a run, as before.
      return [];
    }
  }

  private shouldWaitForExtensions(type: string): boolean {
    return type === "prompt"
      || type === "steer"
      || type === "follow_up"
      || type === "get_commands"
      || type === "get_state";
  }

  private async withFinalIdleReset<T>(operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } finally {
      this.resetIdleTimer();
    }
  }

  /** Apply a coding tool selection; `carry` defaults to the tools active now. */
  setActiveToolSelection(toolNames: string[], carry: readonly string[] = this.inner.getActiveToolNames()): void {
    this.inner.setActiveToolsByName(resolveActiveToolNames(this.inner, toolNames, carry));
  }

  /**
   * pi restores the target branch's loadout from its transcript when it navigates the tree,
   * which can bring back coding tools the pinned preset leaves out and drop codemode, so a
   * normal session applies its selection again when the set changed, and otherwise keeps the
   * order the prompt was in. Chat only declares no tools, and a subagent's tools are fixed by
   * its profile; both keep what pi restored.
   */
  private async navigateTreeKeepingToolSelection(
    targetId: string,
    options: { summarize?: boolean },
  ): Promise<{ cancelled: boolean }> {
    const activeBefore = this.inner.getActiveToolNames();
    const result = await this.inner.navigateTree(targetId, options);
    if (result.cancelled || this.chatOnly) return { cancelled: result.cancelled };

    const entries = this.inner.sessionManager.getEntries() as unknown as SessionEntry[];
    if (!readSubagentSessionResources(entries)) {
      const activeAfter = this.inner.getActiveToolNames();
      const isToolChanged = activeBefore.length !== activeAfter.length
        || activeBefore.some((name) => !activeAfter.includes(name));
      if (isToolChanged) {
        this.setActiveToolSelection(
          readSessionToolSelection(entries) ?? activeAfter,
          [...activeAfter, ...activeBefore.filter((name) => SESSION_TOOL_NAMES.has(name))],
        );
      } else if (activeBefore.some((name, index) => name !== activeAfter[index])) {
        // Same tools, other order: pi declares them in this order, so keep the previous one.
        this.inner.setActiveToolsByName(activeBefore);
      }
    }
    return { cancelled: false };
  }

  private emit(event: AgentEvent): void {
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (error) {
        console.error(
          `[pi-web] failed to deliver ${event.type} event:`,
          error instanceof Error ? error.message : error,
        );
      }
    }
  }

  private async acquirePromptAdmission(): Promise<() => void> {
    const previous = this.promptAdmissionTail;
    let release!: () => void;
    this.promptAdmissionTail = new Promise<void>((resolve) => {
      release = resolve;
    });
    await previous;
    return release;
  }

  private resetIdleTimer(): void {
    if (!this._alive) {
      if (this.idleTimer) clearTimeout(this.idleTimer);
      this.idleDeadlineAt = null;
      return;
    }
    if (!this.isRunning()) this.forceShutdownOnIdle = false;
    // A stuck user reloads, reopens the session or presses Stop again, and
    // each of those commands lands here. Moving the forced deadline for them
    // would keep a run that Stop cannot unwind alive indefinitely.
    if (this.forceShutdownOnIdle && this.forcedIdleTimerArmed) return;
    if (this.idleTimer) clearTimeout(this.idleTimer);
    // A resolved timeout of 0 disables idle shutdown, but a run that Stop could
    // not unwind is still reaped after the default delay; otherwise it stays
    // running until the server restarts (#656).
    const timeoutMs = SESSION_IDLE_TIMEOUT_MS
      || (this.forceShutdownOnIdle ? DEFAULT_SESSION_IDLE_TIMEOUT_MS : 0);
    this.forcedIdleTimerArmed = timeoutMs !== 0 && this.forceShutdownOnIdle;
    this.idleLastResetAt = Date.now();
    if (timeoutMs === 0) {
      this.idleDeadlineAt = null;
      return;
    }
    this.idleDeadlineAt = this.idleLastResetAt + timeoutMs;
    this.idleTimer = setTimeout(() => {
      this.idleDeadlineAt = null;
      if (!this.forceShutdownOnIdle && (this.isRunning() || hasActiveSessionLivenessProvider({
        sessionId: this.sessionId,
        sessionFile: this.sessionFile || undefined,
      }))) {
        this.resetIdleTimer();
        return;
      }
      void this.shutdown().catch((error) => {
        console.error("[pi-web] failed to shut down idle session:", error instanceof Error ? error.message : error);
      });
    }, timeoutMs);
  }

  private persistBashOnlySession(): void {
    const manager = this.inner.sessionManager;
    const sessionFile = manager.getSessionFile();
    if (!sessionFile || existsSync(sessionFile)) return;

    const header = manager.getHeader();
    if (!header) return;

    const content = [header, ...manager.getEntries()]
      .map((entry) => JSON.stringify(entry))
      .join("\n") + "\n";
    writeFileSync(sessionFile, content, { encoding: "utf8", flag: "wx" });

    // Pi delays the first flush until a user or assistant message exists.
    // A leading shell command is neither, so mark this SDK manager as
    // flushed after writing its own generated entries.
    (manager as unknown as { flushed: boolean }).flushed = true;
    cacheSessionPath(this.inner.sessionId, sessionFile);
  }

  onEvent(listener: EventListener): () => void {
    this.listeners.add(listener);
    for (const event of this.pendingUiRequests.values()) listener(event);
    for (const event of this.activeToolEvents.values()) listener(event);
    return () => {
      this.listeners.delete(listener);
    };
  }

  onDestroy(cb: () => void): void {
    this.onDestroyCallback = cb;
  }

  /**
   * Resolves `true` once the SDK session is disposed, or `false` after `timeoutMs`:
   * shutdown() waits for extension binding without a deadline.
   */
  waitUntilDisposed(timeoutMs: number): Promise<boolean> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timedOut = new Promise<boolean>((resolve) => {
      timer = setTimeout(() => resolve(false), timeoutMs);
      timer.unref?.();
    });
    return Promise.race([this.disposed.then(() => true), timedOut]).finally(() => clearTimeout(timer));
  }

  private async withSessionReplacement<T>(
    replacement: "fork" | "clone",
    operation: () => Promise<T>,
  ): Promise<T> {
    if (this.sessionReplacement) throw new Error("Session is already being copied");
    this.sessionReplacement = replacement;
    try {
      return await operation();
    } finally {
      if (this._alive) this.sessionReplacement = null;
    }
  }

  private isSessionRunningForReplacement(): boolean {
    return this.inner.isBashRunning
      || this.inner.isStreaming
      || this.inner.isCompacting
      || this.pendingPromptCount > 0;
  }

  private async shutdownAfterSessionReplacement(replacement: "fork" | "clone"): Promise<void> {
    try {
      await this.shutdown();
    } catch (error) {
      console.error(
        `[pi-web] ${replacement} succeeded, but source session shutdown failed:`,
        error instanceof Error ? error.message : error,
      );
    }
  }

  async send(command: Record<string, unknown>): Promise<unknown> {
    const type = command.type as string;
    // A status read (the chat's reconciliation, every few seconds while it runs) would hide the
    // last command that did something; it never resets the idle timer either.
    if (type !== "get_state") {
      this.lastCommandType = typeof type === "string" ? type : null;
      this.lastCommandAt = Date.now();
    }
    const allowedDuringReplacement = COMMANDS_ALLOWED_DURING_SESSION_REPLACEMENT.has(type);
    if (this.sessionReplacement && !allowedDuringReplacement) {
      throw new Error("Session is being copied to a new session");
    }
    if (SESSION_REPLACEMENT_COMMAND_TYPES.has(type) && this.activeMutatingCommands > 0) {
      throw new Error(`Cannot ${type} while another session command is running`);
    }

    const tracksMutation = !allowedDuringReplacement;
    if (tracksMutation) this.activeMutatingCommands += 1;

    try {
      // Status reconciliation must not postpone forced cleanup after Stop.
      if (type !== "get_state") this.resetIdleTimer();
      if (this.shouldWaitForExtensions(type)) await this.waitForExtensionsBound();
      if (this.sessionReplacement && !allowedDuringReplacement) {
        throw new Error("Session is being copied to a new session");
      }

      if (type === "prompt" || type === "steer" || type === "follow_up") {
        const imageError = validateAgentImages(command.images);
        if (imageError) throw new Error(imageError);
      }
      // A session whose folder was deleted outside pi-web stays readable, but a
      // run there would reach the model only for its tools to fail (and `write`
      // to recreate the folder). The pi CLI does not resume such a session
      // either; refuse as /api/agent/new does. (A `!` command already refuses.)
      // Typed, so the route names the folder for the composer (#1422).
      if (type === "prompt" && !existsSync(this.cwd)) {
        throw cwdMissingError(this.cwd);
      }

      switch (type) {
      case "prompt": {
        // Serialize only admission. Once the preceding prompt has either
        // passed or failed preflight, the SDK can atomically decide whether
        // this submission starts a run or joins its streaming queue.
        const releaseAdmission = await this.acquirePromptAdmission();
        try {
          if (this.inner.isBashRunning) {
            throw new Error("Cannot send a prompt while a shell command is running");
          }
          const model = this.inner.model;
          if (this.chatOnlyExtensionModel && !(model && this.inner.modelRuntime.getModel(model.provider, model.id))) {
            throw chatOnlyExtensionModelError(this.chatOnlyExtensionModel.provider, this.chatOnlyExtensionModel.id);
          }
          if (this.extensionUiAbortController.signal.aborted) {
            this.extensionUiAbortController = new AbortController();
          }
          const promptImages = command.images as Array<{ type: "image"; data: string; mimeType: string }> | undefined;
          const streamingBehavior = command.streamingBehavior as "steer" | "followUp" | undefined;
          let preflightAccepted = false;
          let preflightSettled = false;
          let promptSettled = false;
          // A prompt parked behind compaction is answered with `{ queued: true }`:
          // the message is not a sent one yet.
          let parked = false;
          let acceptPreflight!: () => void;
          let rejectPreflight!: (error: unknown) => void;
          const preflight = new Promise<void>((resolve, reject) => {
            // Acceptance owes no completion: only a run does, and its agent_start says so.
            // An extension command pi handles, or input an extension swallows, starts
            // none, and a run the command starts itself may begin after this (#1345).
            acceptPreflight = () => {
              preflightAccepted = true;
              if (preflightSettled) return;
              preflightSettled = true;
              resolve();
            };
            rejectPreflight = (error) => {
              if (preflightSettled) return;
              preflightSettled = true;
              reject(error);
            };
          });
          const finishPrompt = () => {
            if (promptSettled) return;
            promptSettled = true;
            this.pendingPromptCount = Math.max(0, this.pendingPromptCount - 1);
            this.resetIdleTimer();
            this.notifyAgentRunCompleteIfIdle();
          };

          this.pendingPromptCount += 1;
          // A prompt that may start a run first connects the session's MCP servers and
          // waits for the ones still connecting. The SDK runs before_agent_start before a
          // run has an abort signal, so Stop is honoured here: it ends the wait, and the
          // message is rejected unsent, which returns it to the composer. pi runs an
          // extension command before anything else and starts no run for it: another
          // extension's command skips this, and the built-in `/mcp`, which acts on the
          // registered servers, registers them without waiting (`mcpPromptPreparation()`).
          const mcpPreparation = this.mcpHost && !this.inner.isStreaming
            ? mcpPromptPreparation(typeof command.message === "string" ? command.message : "", this.extensionCommandCandidates())
            : "none";
          if (this.mcpHost && mcpPreparation !== "none") {
            const controller = new AbortController();
            const waited = this.mcpHost.prepareForPrompt(controller.signal, { wait: mcpPreparation === "wait" })
              .catch((error: unknown) => {
                console.error("[pi-web] MCP servers could not be prepared:", error instanceof Error ? error.message : error);
              })
              .then(() => {
                if (!controller.signal.aborted) return;
                finishPrompt();
                throw new Error(MCP_WAIT_STOPPED_MESSAGE);
              });
            const wait = { controller, done: waited.then(() => undefined, () => undefined) };
            this.mcpPromptWait = wait;
            try {
              await waited;
            } finally {
              if (this.mcpPromptWait === wait) this.mcpPromptWait = null;
            }
          }
          // A new prompt, not one queued into a run: what an earlier run's Stop said is over.
          // Not at acceptance: pi accepts a command that awaits a run of its own after that
          // run settled, and the run's Stop must still keep its push and chime away.
          if (!streamingBehavior) this.lastRunAborted = false;
          let prompt: Promise<void>;
          try {
            prompt = this.inner.prompt(command.message as string, {
              ...(promptImages?.length ? { images: promptImages } : {}),
              ...(streamingBehavior ? { streamingBehavior } : {}),
              source: "rpc",
              // Match pi's RPC contract: acknowledge only after synchronous prompt
              // validation and extension preflight have accepted the submission.
              // Every disposition (handled, queued, started) is an acceptance; a
              // rejected prompt never calls this and rejects `prompt` instead.
              preflightResult: () => acceptPreflight(),
            });
          } catch (error) {
            finishPrompt();
            throw error;
          }

          void prompt.then(() => {
            // Compatibility fallback if a future SDK resolves without invoking
            // the internal callback. This waits for the run, but never acks early.
            acceptPreflight();
            finishPrompt();
            if (!streamingBehavior) this.emit(this.promptDoneEvent());
          }, (error) => {
            // pi's SDK refuses prompts while a manual compaction runs. Park the
            // submission and flush it at compaction end (the TUI's
            // compactionQueuedMessages). An extension command typed meanwhile
            // still runs: the SDK executes commands before it refuses. The parked
            // prompt keeps this admission's count outstanding until it settles,
            // so the wrapper cannot idle out from under it.
            if (!preflightAccepted && isCompactionInProgressError(error)) {
              this.parkDuringCompaction({
                message: command.message as string,
                images: promptImages,
                streamingBehavior,
                settle: finishPrompt,
              });
              parked = true;
              acceptPreflight();
              // The refusal can land after that compaction's end already flushed.
              if (!this.inner.isCompacting) this.flushParkedPrompts();
              return;
            }
            rejectPreflight(error);
            finishPrompt();
            invalidateSessionListCache();
            // A preflight rejection is returned by the POST itself. Only an
            // unexpected failure after acceptance needs the asynchronous event.
            if (preflightAccepted) {
              this.emit({
                type: "prompt_error",
                errorMessage: error instanceof Error ? error.message : String(error),
              });
              if (!streamingBehavior) this.emit(this.promptDoneEvent());
            }
          }).catch((error) => {
            console.error(
              "[pi-web] prompt completion handler failed:",
              error instanceof Error ? error.message : error,
            );
          });

          await preflight;
          return parked ? { queued: true } : null;
        } finally {
          releaseAdmission();
        }
      }

      case "abort": {
        this.forceShutdownOnIdle = true;
        // Arm the forced cleanup now: the reset above ran before this flag,
        // and the final reset only runs once the SDK run has unwound.
        this.resetIdleTimer();
        // Stop must unwind extension commands that have not started the agent yet.
        this.extensionUiAbortController.abort(new DOMException("Extension UI cancelled by Stop", "AbortError"));
        // A prompt still waiting for MCP servers is withdrawn before it starts a run.
        if (this.mcpPromptWait) {
          const wait = this.mcpPromptWait;
          wait.controller.abort();
          await wait.done;
        }
        // Stop ends the compaction, whose end would send the parked prompts:
        // they go back to the composer instead, as the TUI's abort restores
        // queued messages to the editor.
        const recalled = this.recallParkedPrompts();
        try {
          await this.withFinalIdleReset(() => this.inner.abort());
          return recalled.steering.length || recalled.followUp.length ? recalled : null;
        } finally {
          if (!this.isRunning()) this.forceShutdownOnIdle = false;
        }
      }

      case "get_state": {
        const model = this.inner.model;
        // Older assistant entries may omit usage. The SDK's post-compaction
        // calculation assumes every projected assistant has it, which made a
        // status read fail with 500. Context usage is optional in this state;
        // the chat can still render and refresh it on the next response.
        let contextUsage: ReturnType<AgentSessionLike["getContextUsage"]>;
        try {
          contextUsage = this.inner.getContextUsage();
        } catch {
          contextUsage = undefined;
        }
        return {
          sessionId: this.inner.sessionId,
          sessionFile: this.inner.sessionFile ?? "",
          isStreaming: this.inner.isStreaming,
          isPromptRunning: this.pendingPromptCount > 0,
          isBashRunning: this.inner.isBashRunning,
          isCompacting: this.inner.isCompacting,
          autoCompactionEnabled: this.inner.autoCompactionEnabled,
          autoRetryEnabled: this.inner.autoRetryEnabled,
          model: model ? { id: model.id, provider: model.provider } : undefined,
          messageCount: 0,
          pendingMessageCount: this.inner.pendingMessageCount,
          queuedMessages: this.mergedQueuedMessages(),
          contextUsage: contextUsage
            ? { percent: contextUsage.percent, contextWindow: contextUsage.contextWindow, tokens: contextUsage.tokens }
            : null,
          // Computed from the live entries on every read, like `GET /api/sessions/[id]`
          // does for a snapshot: the SDK's stats carry no active time, and a panel that
          // kept a snapshot while messages streamed in showed the pre-gap value for the
          // rest of the run, however long it lasted (#1334).
          totalActiveMs: computeLiveSessionTotalActiveMs(this.inner.sessionManager),
          // An exact prompt is projected onto each run by the inline extension. Every other
          // session reports `agent.state.systemPrompt`, which replays the transcript: that is
          // what the model actually saw, including sections a `before_agent_start` handler
          // changed for the run. It stays empty until the first run persists a system message,
          // so a session that has not sent anything yet falls back to the session getter, which
          // renders the prompt from the current options. The getter alone would drop those
          // per-run changes again once the run ends.
          systemPrompt: this.exactSystemPrompt?.() ?? (this.inner.agent.state?.systemPrompt || this.inner.systemPrompt || ""),
          thinkingLevel: this.inner.agent.state?.thinkingLevel ?? "off",
          extensionStatuses: this.getExtensionStatuses(),
          extensionWidgets: this.getExtensionWidgets(),
        };
      }

      case "set_model": {
        const { provider, modelId } = command as { provider: string; modelId: string };
        // As pi's /model, which refreshes before listing: re-read models.json even for a known id,
        // so reselecting a model applies a saved edit of it (#1273). Like the TUI, a failed or
        // timed-out refresh leaves the cached definitions in use.
        await this.inner.modelRuntime.refresh({
          allowNetwork: false,
          providers: [provider],
          signal: AbortSignal.timeout(MODEL_REFRESH_TIMEOUT_MS),
        }).catch(() => undefined);
        const model = this.inner.modelRuntime.getModel(provider, modelId);
        if (!model) {
          throw this.chatOnly && findDeferredModel(this.inner.modelRuntime as ModelRuntime, provider, modelId)
            ? chatOnlyExtensionModelError(provider, modelId)
            : new Error(`Model not found: ${provider}/${modelId}`);
        }
        const previous = this.inner.model;
        // Reselecting an unchanged model writes nothing.
        if (isDeepStrictEqual(previous, model)) return { id: model.id, provider: model.provider };
        const sameId = previous?.provider === model.provider && previous.id === model.id;
        const thinkingLevel = this.inner.agent.state?.thinkingLevel;
        await this.inner.setModel(model);
        // A reselect to apply an edit is not a new model choice: keep the level (clamped by the SDK).
        if (sameId && thinkingLevel) this.inner.setThinkingLevel(thinkingLevel);
        invalidateModelsCache();
        invalidateSessionListCache();
        return { id: model.id, provider: model.provider };
      }

      case "fork": {
        if (this.inner.isBashRunning) {
          throw new Error("Cannot fork while a shell command is running");
        }
        // Forking copies finished entries from disk into a new file and never
        // touches this AgentSession, so a running source keeps its run. Only an
        // idle source is shut down, because the browser moves to the child.
        const keepSource = this.isSessionRunningForReplacement();
        return this.withSessionReplacement("fork", async () => {
          const entryId = command.entryId as string;
          const sessionManager = this.inner.sessionManager;
          const currentSessionFile = this.inner.sessionFile;

          if (!sessionManager.isPersisted()) return { cancelled: true };
          if (!currentSessionFile) throw new Error("Persisted session is missing a session file");

          const entry = sessionManager.getEntry(entryId);
          if (!entry) throw new Error("Invalid entry ID for forking");

          const sessionDir = sessionManager.getSessionDir();
          let newSessionFile: string;
          let forkedManager: SessionManager;

          if (!entry.parentId) {
            // Fork before the first message: create an empty session linked to this one
            forkedManager = SessionManager.create(sessionManager.getCwd(), sessionDir, {
              parentSession: currentSessionFile,
            });
            newSessionFile = forkedManager.getSessionFile() as string;
          } else {
            // Fork after some history: copy path up to (but not including) the fork point
            if (!existsSync(currentSessionFile)) throw new Error(UNSAVED_SESSION_FORK_ERROR);
            forkedManager = SessionManager.open(currentSessionFile, sessionDir);
            const forkedPath = forkedManager.createBranchedSession(entry.parentId);
            if (!forkedPath) throw new Error("Failed to create forked session");
            newSessionFile = forkedPath;
          }

          if (!existsSync(newSessionFile)) {
            const header = forkedManager.getHeader();
            if (!header) throw new Error("Forked session is missing a session header");
            const content = [header, ...forkedManager.getEntries()]
              .map((forkedEntry) => JSON.stringify(forkedEntry))
              .join("\n") + "\n";
            writeFileSync(newSessionFile, content, { encoding: "utf8", flag: "wx" });
          }

          const newSessionId = forkedManager.getSessionId();
          cacheSessionPath(newSessionId, newSessionFile);
          invalidateSessionListCache();
          if (!keepSource) await this.shutdownAfterSessionReplacement("fork");
          return { cancelled: false, newSessionId };
        });
      }

      case "fork_branch": {
        if (this.inner.isBashRunning) {
          throw new Error("Cannot fork while a shell command is running");
        }
        const entryId = command.entryId as string;
        const sessionManager = this.inner.sessionManager;
        const currentSessionFile = this.inner.sessionFile;
        if (!sessionManager.isPersisted()) return { cancelled: true };
        if (!currentSessionFile) throw new Error("Persisted session is missing a session file");
        if (!sessionManager.getEntry(entryId)) throw new Error("Invalid entry ID for forking");
        if (!existsSync(currentSessionFile)) throw new Error(UNSAVED_SESSION_FORK_ERROR);

        const sessionDir = sessionManager.getSessionDir();
        const sourceManager = SessionManager.open(currentSessionFile, sessionDir);
        const forkedPath = sourceManager.createBranchedSession(entryId);
        if (!forkedPath) throw new Error("Failed to create forked session");

        const newSessionId = SessionManager.open(forkedPath, sessionDir).getSessionId();
        cacheSessionPath(newSessionId, forkedPath);
        invalidateSessionListCache();
        return { cancelled: false, newSessionId };
      }

      case "clone": {
        if (this.isSessionRunningForReplacement()) {
          throw new Error("Cannot clone while the session is running");
        }
        const sessionManager = this.inner.sessionManager;
        const currentSessionFile = this.inner.sessionFile;
        const leafId = typeof command.leafId === "string" ? command.leafId : sessionManager.getLeafId();
        const branchHasAssistant = leafId && sessionManager.getBranch(leafId).some(
          (entry) => entry.type === "message" && entry.message.role === "assistant",
        );

        if (!sessionManager.isPersisted() || !leafId || !branchHasAssistant) return { cancelled: true };
        if (!currentSessionFile || !existsSync(currentSessionFile)) return { cancelled: true };

        return this.withSessionReplacement("clone", async () => {
          const sessionDir = sessionManager.getSessionDir();
          const sourceManager = SessionManager.open(currentSessionFile, sessionDir);
          const clonedPath = sourceManager.createBranchedSession(leafId);
          if (!clonedPath || !existsSync(clonedPath)) throw new Error("Failed to clone current session branch");

          const newSessionId = SessionManager.open(clonedPath, sessionDir).getSessionId();
          cacheSessionPath(newSessionId, clonedPath);
          invalidateSessionListCache();
          await this.shutdownAfterSessionReplacement("clone");
          return { cancelled: false, newSessionId };
        });
      }

      case "navigate_tree": {
        if (this.inner.isBashRunning) {
          throw new Error("Cannot navigate while a shell command is running");
        }
        return this.navigateTreeKeepingToolSelection(command.targetId as string, {});
      }

      case "set_thinking_level": {
        const level = command.level as string;
        this.inner.setThinkingLevel(level);
        // setThinkingLevel clamps xhigh→high for models where supportsXhigh()===false.
        // If the model has DeepSeek thinking compat (reasoningEffortMap maps xhigh→max),
        // force the state back so the compat layer can use it correctly.
        if (level === "xhigh" && (this.inner.model as { compat?: { thinkingFormat?: string } } | null)?.compat?.thinkingFormat === "deepseek" && this.inner.agent?.state) {
          this.inner.agent.state.thinkingLevel = "xhigh";
        }
        invalidateSessionListCache();
        return null;
      }

      case "compact": {
        try {
          return await this.withFinalIdleReset(() =>
            this.inner.compact(command.customInstructions as string | undefined)
          );
        } finally {
          invalidateSessionListCache();
        }
      }

      case "set_session_name": {
        const name = (command.name as string | undefined)?.trim();
        if (!name) throw new Error("Session name cannot be empty");
        this.inner.setSessionName(name);
        invalidateSessionListCache();
        return null;
      }

      case "get_session_stats": {
        return {
          ...this.inner.getSessionStats(),
          sessionName: this.inner.sessionManager.getSessionName(),
        };
      }

      case "get_last_assistant_text": {
        return { text: this.inner.getLastAssistantText() ?? "" };
      }

      case "set_auto_compaction": {
        this.inner.setAutoCompactionEnabled(command.enabled as boolean);
        return null;
      }

      case "clear_queue": {
        // Full clear only: pi has no single-item dequeue, and clear+requeue
        // races against the agent loop pulling messages mid-flight. Prompts
        // parked during compaction come back too, as the TUI's clearAllQueues().
        const cleared = this.inner.clearQueue();
        if (this.parkedDuringCompaction.length === 0) return cleared;
        const recalled = this.recallParkedPrompts();
        return {
          steering: [...cleared.steering, ...recalled.steering],
          followUp: [...cleared.followUp, ...recalled.followUp],
          ...(recalled.images ? { images: recalled.images } : {}),
        };
      }

      case "steer": {
        const steerImages = command.images as Array<{ type: "image"; data: string; mimeType: string }> | undefined;
        await this.inner.steer(command.message as string, steerImages?.length ? steerImages : undefined);
        return null;
      }

      case "follow_up": {
        const followImages = command.images as Array<{ type: "image"; data: string; mimeType: string }> | undefined;
        await this.inner.followUp(command.message as string, followImages?.length ? followImages : undefined);
        return null;
      }

      case "get_tools": {
        // A hidden tool is withdrawn: pi ignores it when setting the active tools.
        const all: ToolInfo[] = this.inner.getAllTools().filter((t) => t.exposure !== "hidden");
        const active = new Set<string>(this.inner.getActiveToolNames());
        // The definition's description is not always what the model gets: `prepareLoadout`
        // hooks rewrite the declared ones (codemode lists its nested tools and the MCP types).
        const declared = new Map((this.inner.agent.state?.tools ?? []).map((t) => [t.name, t.description]));
        // Active and callable, but requests leave the declaration out: codemode's "only" mode
        // does this to active `direct` tools. The set is private to pi 0.99's AgentSession.
        const hiddenDeclarations: unknown = Reflect.get(this.inner, "_hiddenDeclarations");
        const hidden = hiddenDeclarations instanceof Set ? hiddenDeclarations : new Set<unknown>();
        return all.map((t) => ({
          ...t,
          description: declared.get(t.name) ?? t.description,
          active: active.has(t.name),
          declarationHidden: hidden.has(t.name),
        }));
      }

      case "get_commands": {
        const commands: SlashCommandInfo[] = [];
        for (const registered of this.inner.extensionRunner.getRegisteredCommands()) {
          commands.push({
            name: registered.invocationName,
            description: registered.description,
            source: "extension",
            sourceInfo: registered.sourceInfo,
          });
        }
        for (const template of this.inner.promptTemplates) {
          commands.push({
            name: template.name,
            description: template.description,
            source: "prompt",
            sourceInfo: template.sourceInfo,
          });
        }
        for (const skill of this.inner.resourceLoader.getSkills().skills) {
          commands.push({
            name: `skill:${skill.name}`,
            description: skill.description,
            source: "skill",
            sourceInfo: skill.sourceInfo,
          });
        }
        return { commands };
      }

      case "set_tools": {
        const toolNames = command.toolNames as string[];
        this.setActiveToolSelection(toolNames);
        return null;
      }

      case "reload": {
        // A reload invalidates the extension ctx the running turn still holds,
        // and the turn dies at its next extension hook (#1172). pi refuses too.
        if (this.isSessionRunningForReplacement()) {
          throw new Error("Wait for the current response to finish before reloading.");
        }
        if (this.extensionUiAbortController.signal.aborted) {
          this.extensionUiAbortController = new AbortController();
        }
        const activeToolNames = this.inner.getActiveToolNames();
        await this.waitForExtensionsBound();
        this.extensionStatuses.clear();
        this.resetExtensionWidgetsForReload();
        this.syncProjectTrust();
        await this.inner.reload();
        // pi rebuilds from the tools active before, then extensions adjust them as they start
        // again; carry that result so a tool one switched off during reload stays off.
        this.setActiveToolSelection(activeToolNames);
        if (typeof this.inner.bindExtensions !== "function") {
          this.inner.extensionRunner.setUIContext?.(this.createExtensionUiContext(), "rpc");
        }
        invalidateModelsCache();
        // /reload is how an edited extension is picked up; the provider lists' runtime follows.
        invalidateModelRuntimeWithExtensions();
        return { success: true };
      }

      case "abort_compaction": {
        this.inner.abortCompaction();
        return null;
      }

      case "extension_ui_response": {
        this.resolveExtensionUiResponse(command as ExtensionUiResponse);
        return null;
      }

      case "extension_ui_input": {
        this.handleExtensionUiInput(command.id as string, command.data as string);
        return null;
      }

      case "set_auto_retry": {
        this.inner.setAutoRetryEnabled(command.enabled as boolean);
        return null;
      }

      case "bash": {
        if (this.pendingPromptCount > 0 || this.inner.isStreaming || this.inner.isCompacting || this.inner.isBashRunning) {
          throw new Error("Cannot run a shell command while the session is busy");
        }
        const execution = this.inner.executeBash(
          command.command as string,
          undefined,
          {
            excludeFromContext: command.excludeFromContext as boolean | undefined,
            operations: createProjectCommandBashOperations({
              shellPath: this.inner.settingsManager.getShellPath(),
            }),
          },
        );
        try {
          const result = await execution;
          this.persistBashOnlySession();
          return result;
        } finally {
          this.resetIdleTimer();
          invalidateSessionListCache();
        }
      }

      case "abort_bash": {
        this.forceShutdownOnIdle = true;
        this.resetIdleTimer();
        this.inner.abortBash();
        return null;
      }

        default:
          throw new Error(`Unsupported command: ${type}`);
      }
    } finally {
      if (tracksMutation) this.activeMutatingCommands = Math.max(0, this.activeMutatingCommands - 1);
    }
  }

  /**
   * Once, as closing starts and before extensions hear session_shutdown: the
   * MCP host's own handler runs after every other extension's, and one that
   * never returns would leave its records behind (lib/mcp-host.ts).
   */
  private disposeMcpHost(): void {
    if (this.mcpHostDisposed) return;
    this.mcpHostDisposed = true;
    try {
      this.mcpHost?.dispose();
    } catch (error) {
      console.error("[pi-web] MCP host dispose failed:", error instanceof Error ? error.message : error);
    }
  }

  destroy(): void {
    if (!this._alive) return;
    this._alive = false;
    this.closingAt ??= Date.now();
    this.disposeMcpHost();
    // Tell attached SSE listeners to drop this instance so the browser
    // EventSource errors and reconnects instead of staying OPEN on a dead wrapper.
    this.emit({ type: "session_shutdown" });
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.idleDeadlineAt = null;
    if (this.inner.isBashRunning) this.inner.abortBash();
    this.unsubscribe?.();
    for (const pending of this.pendingUiResponses.values()) pending.cancel();
    for (const id of Array.from(this.activeCustomUis.keys())) this.closeCustomUi(id, undefined);
    this.pendingUiResponses.clear();
    this.pendingUiRequests.clear();
    this.activeToolEvents.clear();
    this.clearExtensionWidgets(false);

    const finishDispose = () => {
      try {
        this.inner.dispose();
      } finally {
        this.onDestroyCallback?.();
        // Here rather than in the registry's onDestroy callback, which a replacement swaps out.
        recordSessionClosed(this);
        this.resolveDisposed();
      }
    };

    // Always emit session_shutdown before dispose, even when callers skip
    // shutdown() (process exit, direct destroy). Await when possible so
    // extension MCP children can reap before the runner is invalidated.
    if (this.sessionShutdownEmitted) {
      finishDispose();
      return;
    }

    this.sessionShutdownEmitted = true;
    const emit = this.inner.extensionRunner?.emit;
    if (typeof emit !== "function") {
      finishDispose();
      return;
    }

    void this.emitSessionShutdown(emit)
      .catch((error) => {
        console.error(
          "[pi-web] session_shutdown before dispose failed:",
          error instanceof Error ? error.message : error,
        );
      })
      .finally(finishDispose);
  }

  async shutdown(): Promise<void> {
    if (this.shutdownPromise) return this.shutdownPromise;
    if (!this._alive) return;
    // Closing starts before the first await, so a request that arrives while
    // extensions shut down starts a fresh wrapper instead of prompting this one.
    this.closing = true;
    this.closingAt ??= Date.now();

    this.shutdownPromise = (async () => {
      try {
        try {
          await this.waitForExtensionsBound();
        } catch (error) {
          console.error(
            "[pi-web] extension binding failed before session shutdown:",
            error instanceof Error ? error.message : error,
          );
        }
        // After binding, so the host's session_start has run and finds nothing to record later.
        this.disposeMcpHost();
        if (!this.sessionShutdownEmitted) {
          this.sessionShutdownEmitted = true;
          const emit = this.inner.extensionRunner?.emit;
          if (typeof emit === "function") await this.emitSessionShutdown(emit);
        }
      } finally {
        this.destroy();
      }
    })();
    return this.shutdownPromise;
  }

  /**
   * Gives extensions at most SESSION_SHUTDOWN_DEADLINE_MS to handle
   * session_shutdown, then returns so the SDK session is disposed and
   * unregistered anyway. Closing an MCP connection has no upper bound: it waits
   * for a token refresh in flight and for a stdio child whose daemonized
   * grandchild may never close stdout.
   */
  private async emitSessionShutdown(
    emit: NonNullable<AgentSessionLike["extensionRunner"]["emit"]>,
  ): Promise<void> {
    let deadlineTimer: ReturnType<typeof setTimeout> | undefined;
    const deadline = new Promise<"timeout">((resolve) => {
      deadlineTimer = setTimeout(() => resolve("timeout"), SESSION_SHUTDOWN_DEADLINE_MS);
      // A quitting process must not wait for an extension's cleanup.
      deadlineTimer.unref?.();
    });
    // A synchronous throw becomes a rejection, and a rejection that arrives
    // after the deadline is still handled by the race below.
    const handled = (async () => {
      await emit.call(this.inner.extensionRunner, { type: "session_shutdown", reason: "quit" });
      return "handled" as const;
    })();
    try {
      if (await Promise.race([handled, deadline]) === "timeout") {
        console.warn(
          `[pi-web] extensions did not finish session_shutdown for session ${this.sessionId} within ${SESSION_SHUTDOWN_DEADLINE_MS} ms; disposing it anyway`,
        );
      }
    } finally {
      clearTimeout(deadlineTimer);
    }
  }

  private resolveExtensionUiResponse(response: ExtensionUiResponse): void {
    const pending = this.pendingUiResponses.get(response.id);
    if (!pending) return;
    pending.resolve(response);
  }

  private getExtensionStatuses(): Array<{ key: string; text: string }> {
    return Array.from(this.extensionStatuses, ([key, text]) => ({ key, text }));
  }

  private getExtensionWidgets(): ExtensionWidgetItem[] {
    return Array.from(this.extensionWidgets.values());
  }

  private nextExtensionWidgetGeneration(key: string): number {
    const generation = (this.extensionWidgetGenerations.get(key) ?? 0) + 1;
    this.extensionWidgetGenerations.set(key, generation);
    return generation;
  }

  private disposeExtensionWidgetComponent(component: unknown): void {
    if (!component || (typeof component !== "object" && typeof component !== "function")) return;
    const dispose = (component as { dispose?: unknown }).dispose;
    if (typeof dispose !== "function") return;
    try {
      dispose.call(component);
    } catch {
      // Ignore dispose errors from extension widgets.
    }
  }

  private emitExtensionWidgetClear(key: string): void {
    this.emit({
      type: "extension_ui_request",
      id: randomUUID(),
      method: "setWidget",
      widgetKey: key,
      widgetLines: undefined,
      widgetPlacement: undefined,
    } as ExtensionUiRequest as AgentEvent);
  }

  private clearExtensionWidget(key: string, emitClear = true): number {
    const generation = this.nextExtensionWidgetGeneration(key);

    const active = this.activeExtensionWidgets.get(key);
    this.activeExtensionWidgets.delete(key);
    this.extensionWidgets.delete(key);
    if (active) this.disposeExtensionWidgetComponent(active.component);
    if (this.extensionWidgetGenerations.get(key) !== generation) return generation;
    if (emitClear) this.emitExtensionWidgetClear(key);
    return generation;
  }

  private clearExtensionWidgets(emitClear: boolean): void {
    const keys = new Set([
      ...this.extensionWidgets.keys(),
      ...this.activeExtensionWidgets.keys(),
    ]);
    for (const key of keys) this.clearExtensionWidget(key, emitClear);
  }

  private resetExtensionWidgetsForReload(): void {
    this.extensionWidgetsResetting = true;
    try {
      const factoryKeys = [...this.activeExtensionWidgets.keys()];
      for (const key of factoryKeys) this.clearExtensionWidget(key);
      // Keep the existing array-widget reload behavior: snapshots are reset and
      // the next extension session_start repopulates them.
      this.extensionWidgets.clear();
    } finally {
      this.extensionWidgetsResetting = false;
    }
  }

  private emitExtensionWidgetError(key: string, error: unknown): void {
    this.emit({
      type: "extension_error",
      extensionPath: `extension-widget:${key}`,
      event: "setWidget",
      error: error instanceof Error ? error.message : String(error),
    });
  }

  private failExtensionWidget(
    key: string,
    generation: number,
    error: unknown,
    clearEmitted: boolean,
    component?: unknown,
  ): void {
    if (this.extensionWidgetGenerations.get(key) !== generation) {
      this.disposeExtensionWidgetComponent(component);
      return;
    }

    const active = this.activeExtensionWidgets.get(key);
    let shouldEmitClear = !clearEmitted;
    if (active?.generation === generation) {
      shouldEmitClear = active.rendered || !active.clearEmitted;
      this.activeExtensionWidgets.delete(key);
      this.disposeExtensionWidgetComponent(active.component);
    } else {
      this.disposeExtensionWidgetComponent(component);
    }
    if (this.extensionWidgetGenerations.get(key) !== generation) {
      this.emitExtensionWidgetError(key, error);
      return;
    }
    this.extensionWidgets.delete(key);
    if (shouldEmitClear) this.emitExtensionWidgetClear(key);
    this.emitExtensionWidgetError(key, error);
  }

  private renderExtensionWidget(active: ActiveExtensionWidget): void {
    if (
      this.activeExtensionWidgets.get(active.key) !== active
      || this.extensionWidgetGenerations.get(active.key) !== active.generation
    ) return;

    let lines: unknown;
    try {
      lines = active.component.render(DEFAULT_CUSTOM_UI_COLUMNS);
    } catch (error) {
      this.failExtensionWidget(active.key, active.generation, error, active.clearEmitted);
      return;
    }
    if (!Array.isArray(lines) || !lines.every((line) => typeof line === "string")) {
      this.failExtensionWidget(
        active.key,
        active.generation,
        new Error("Extension widget render must return string[]"),
        active.clearEmitted,
      );
      return;
    }
    if (
      this.activeExtensionWidgets.get(active.key) !== active
      || this.extensionWidgetGenerations.get(active.key) !== active.generation
    ) return;

    const widgetLines = lines as string[];
    this.extensionWidgets.set(active.key, {
      key: active.key,
      lines: widgetLines,
      placement: active.placement,
    });
    active.rendered = true;
    this.emit({
      type: "extension_ui_request",
      id: randomUUID(),
      method: "setWidget",
      widgetKey: active.key,
      widgetLines,
      widgetPlacement: active.placement,
    } as ExtensionUiRequest as AgentEvent);
  }

  private setExtensionWidgetFactory(
    key: string,
    factory: ExtensionWidgetFactory,
    options?: { placement?: "aboveEditor" | "belowEditor" },
  ): void {
    const hadPrevious = this.extensionWidgets.has(key) || this.activeExtensionWidgets.has(key);
    const generation = this.clearExtensionWidget(key, hadPrevious);
    if (this.extensionWidgetGenerations.get(key) !== generation) return;
    const tui = createHeadlessCustomUiTui(() => {
      const active = this.activeExtensionWidgets.get(key);
      if (active?.generation === generation) this.renderExtensionWidget(active);
    }, DEFAULT_CUSTOM_UI_COLUMNS);

    let component: unknown;
    try {
      component = factory(tui, PLAIN_TEXT_THEME);
    } catch (error) {
      this.failExtensionWidget(key, generation, error, hadPrevious);
      return;
    }
    if (this.extensionWidgetGenerations.get(key) !== generation) {
      this.disposeExtensionWidgetComponent(component);
      return;
    }
    if (
      !component
      || (typeof component !== "object" && typeof component !== "function")
      || typeof (component as { render?: unknown }).render !== "function"
    ) {
      this.failExtensionWidget(
        key,
        generation,
        new Error("Extension widget factory must return a component with render(width)"),
        hadPrevious,
        component,
      );
      return;
    }

    const active: ActiveExtensionWidget = {
      key,
      component: component as ExtensionWidgetComponent,
      placement: options?.placement ?? "aboveEditor",
      generation,
      clearEmitted: hadPrevious,
      rendered: false,
    };
    this.activeExtensionWidgets.set(key, active);
    this.renderExtensionWidget(active);
  }

  private getCustomUiWidth(options: unknown): number {
    if (!options || typeof options !== "object") return DEFAULT_CUSTOM_UI_COLUMNS;
    const overlayOptions = (options as { overlayOptions?: unknown }).overlayOptions;
    const resolved = typeof overlayOptions === "function" ? overlayOptions() : overlayOptions;
    if (!resolved || typeof resolved !== "object") return DEFAULT_CUSTOM_UI_COLUMNS;
    const width = (resolved as { width?: unknown }).width;
    return typeof width === "number" && Number.isFinite(width)
      ? Math.max(40, Math.min(140, Math.round(width)))
      : 92;
  }

  private emitCustomUiRender(id: string, custom: ActiveCustomUi): void {
    let lines: string[];
    try {
      lines = custom.component.render(custom.width);
    } catch (error) {
      lines = [`Extension custom UI render failed: ${error instanceof Error ? error.message : String(error)}`];
    }
    const event = {
      type: "extension_ui_request",
      id,
      method: "custom",
      lines,
    } as ExtensionUiRequest as AgentEvent;
    this.pendingUiRequests.set(id, event);
    this.emit(event);
  }

  private closeCustomUi(id: string, value: unknown): void {
    const custom = this.activeCustomUis.get(id);
    if (!custom || custom.settled) return;
    custom.settled = true;
    this.activeCustomUis.delete(id);
    this.pendingUiRequests.delete(id);
    try {
      custom.component.dispose?.();
    } catch {
      // Ignore dispose errors from extension UI components.
    }
    this.emit({
      type: "extension_ui_request",
      id,
      method: "custom",
      lines: [],
      closed: true,
    } as ExtensionUiRequest as AgentEvent);
    custom.resolve(value);
  }

  private handleExtensionUiInput(id: string, data: string): void {
    const custom = this.activeCustomUis.get(id);
    if (!custom || typeof data !== "string") return;
    try {
      custom.component.handleInput?.(data);
      if (this.activeCustomUis.has(id)) this.emitCustomUiRender(id, custom);
    } catch (error) {
      this.closeCustomUi(id, undefined);
      this.emit({
        type: "extension_error",
        extensionPath: `custom-ui:${id}`,
        event: "custom_ui_input",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  private requestExtensionCustomUi<T>(
    factory: unknown,
    options?: unknown,
  ): Promise<T> {
    if (typeof factory !== "function") return Promise.resolve(undefined as T);

    const stopSignal = this.extensionUiAbortController.signal;
    if (stopSignal.aborted) return Promise.reject(stopSignal.reason);

    const id = randomUUID();
    const width = this.getCustomUiWidth(options);

    return new Promise<T>((resolve, reject) => {
      let completed = false;
      const tui = createHeadlessCustomUiTui(
        () => {
          const custom = this.activeCustomUis.get(id);
          if (custom) this.emitCustomUiRender(id, custom);
        },
        width,
      );
      const finish = (value: T) => {
        if (completed) return;
        completed = true;
        stopSignal.removeEventListener("abort", onStop);
        if (stopSignal.aborted) reject(stopSignal.reason);
        else resolve(value);
      };
      const done = (value: T) => {
        if (this.activeCustomUis.has(id)) {
          this.closeCustomUi(id, value);
        } else {
          finish(value);
        }
      };
      const onStop = () => done(undefined as T);
      stopSignal.addEventListener("abort", onStop, { once: true });

      Promise.resolve()
        .then(() => completed ? undefined : factory(tui, PLAIN_TEXT_THEME, CUSTOM_UI_KEYBINDINGS, done))
        .then((component) => {
          if (completed) {
            try {
              (component as CustomUiComponent | undefined)?.dispose?.();
            } catch {
              // Ignore dispose errors from a component completed before mounting.
            }
            return;
          }
          if (!component || typeof component !== "object" || typeof (component as CustomUiComponent).render !== "function") {
            finish(undefined as T);
            return;
          }
          const custom: ActiveCustomUi = {
            component: component as CustomUiComponent,
            width,
            resolve: (value) => finish(value as T),
            settled: false,
          };
          this.activeCustomUis.set(id, custom);
          this.emitCustomUiRender(id, custom);
        })
        .catch((error) => {
          if (completed) return;
          this.emit({
            type: "extension_error",
            extensionPath: `custom-ui:${id}`,
            event: "custom_ui",
            error: error instanceof Error ? error.message : String(error),
          });
          finish(undefined as T);
        });
    });
  }

  private requestExtensionUi<T>(
    request: ExtensionUiRequestBody,
    defaultValue: T,
    parseResponse: (response: ExtensionUiResponse) => T,
    timeout?: number,
    signal?: AbortSignal,
  ): Promise<T> {
    if (signal?.aborted) return Promise.resolve(defaultValue);
    const stopSignal = this.extensionUiAbortController.signal;
    if (stopSignal.aborted) return Promise.reject(stopSignal.reason);
    const abortSignal = signal ? AbortSignal.any([signal, stopSignal]) : stopSignal;

    const id = randomUUID();
    const fullRequest = {
      type: "extension_ui_request",
      id,
      ...request,
      ...(timeout ? { timeout, expiresAt: Date.now() + timeout } : {}),
    };

    return new Promise((resolve, reject) => {
      let settled = false;
      let timeoutId: ReturnType<typeof setTimeout> | undefined;
      const cleanup = () => {
        if (timeoutId) clearTimeout(timeoutId);
        abortSignal.removeEventListener("abort", onAbort);
        this.pendingUiRequests.delete(id);
        this.pendingUiResponses.delete(id);
        this.emit({ type: "extension_ui_closed", id });
      };
      const settle = (value: T) => {
        if (settled) return;
        settled = true;
        cleanup();
        if (stopSignal.aborted) reject(stopSignal.reason);
        else resolve(value);
      };
      const onAbort = () => settle(defaultValue);

      if (timeout) timeoutId = setTimeout(() => settle(defaultValue), timeout);
      abortSignal.addEventListener("abort", onAbort, { once: true });

      this.pendingUiRequests.set(id, fullRequest as AgentEvent);
      this.pendingUiResponses.set(id, {
        resolve: (response) => settle(parseResponse(response)),
        cancel: () => settle(defaultValue),
      });
      this.emit(fullRequest as AgentEvent);
    });
  }

  private createExtensionUiContext(): ExtensionUiContextLike {
    return {
      select: (title, options, opts) => this.requestExtensionUi(
        { method: "select", title, options, ...(opts?.timeout ? { timeout: opts.timeout } : {}) },
        undefined,
        (response) => "value" in response ? response.value : undefined,
        opts?.timeout,
        opts?.signal,
      ),
      confirm: (title, message, opts) => this.requestExtensionUi(
        { method: "confirm", title, message, ...(opts?.timeout ? { timeout: opts.timeout } : {}) },
        false,
        (response) => "confirmed" in response ? response.confirmed : false,
        opts?.timeout,
        opts?.signal,
      ),
      input: (title, placeholder, opts) => this.requestExtensionUi(
        { method: "input", title, ...(placeholder !== undefined ? { placeholder } : {}), ...(opts?.timeout ? { timeout: opts.timeout } : {}) },
        undefined,
        (response) => "value" in response ? response.value : undefined,
        opts?.timeout,
        opts?.signal,
      ),
      editor: (title, prefill, opts) => this.requestExtensionUi(
        { method: "editor", title, ...(prefill !== undefined ? { prefill } : {}), ...(opts?.timeout ? { timeout: opts.timeout } : {}) },
        undefined,
        (response) => "value" in response ? response.value : undefined,
        opts?.timeout,
        opts?.signal,
      ),
      notify: (message, type) => {
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "notify",
          message,
          notifyType: type,
        } as ExtensionUiRequest as AgentEvent);
      },
      onTerminalInput: () => () => {},
      setStatus: (key, text) => {
        if (text === undefined) this.extensionStatuses.delete(key);
        else this.extensionStatuses.set(key, text);
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "setStatus",
          statusKey: key,
          statusText: text,
        } as ExtensionUiRequest as AgentEvent);
      },
      setWorkingMessage: () => {},
      setWorkingVisible: () => {},
      setWorkingIndicator: () => {},
      setHiddenThinkingLabel: () => {},
      setWidget: (key, content, options) => {
        if (!this._alive || this.extensionWidgetsResetting) return;
        if (typeof content === "function") {
          this.setExtensionWidgetFactory(
            key,
            content as unknown as ExtensionWidgetFactory,
            options,
          );
          return;
        }
        if (content !== undefined && !Array.isArray(content)) return;
        if (content === undefined) {
          this.clearExtensionWidget(key);
          return;
        }
        const generation = this.activeExtensionWidgets.has(key)
          ? this.clearExtensionWidget(key)
          : this.nextExtensionWidgetGeneration(key);
        if (this.extensionWidgetGenerations.get(key) !== generation) return;
        this.extensionWidgets.set(key, {
          key,
          lines: content,
          placement: options?.placement ?? "aboveEditor",
        });
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "setWidget",
          widgetKey: key,
          widgetLines: content,
          widgetPlacement: options?.placement,
        } as ExtensionUiRequest as AgentEvent);
      },
      setFooter: () => {},
      setHeader: () => {},
      setTitle: (title) => {
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "setTitle",
          title,
        } as ExtensionUiRequest as AgentEvent);
      },
      custom: <T = unknown>(factory: unknown, options?: unknown) => this.requestExtensionCustomUi<T>(factory, options),
      pasteToEditor: (text) => {
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "set_editor_text",
          text,
        } as ExtensionUiRequest as AgentEvent);
      },
      setEditorText: (text) => {
        this.emit({
          type: "extension_ui_request",
          id: randomUUID(),
          method: "set_editor_text",
          text,
        } as ExtensionUiRequest as AgentEvent);
      },
      getEditorText: () => "",
      addAutocompleteProvider: () => {},
      setEditorComponent: () => {},
      getEditorComponent: () => undefined,
      get theme() { return PLAIN_TEXT_THEME; },
      getAllThemes: () => [],
      getTheme: () => undefined,
      setTheme: () => ({ success: false, error: "Theme switching is not supported in Pi Web extension UI yet" }),
      getToolsExpanded: () => false,
      setToolsExpanded: () => {},
    };
  }

  private createExtensionCommandContextActions(): ExtensionCommandContextActionsLike {
    return {
      waitForIdle: async () => {
        const agent = this.inner.agent as { waitForIdle?: () => Promise<void> };
        await agent.waitForIdle?.();
      },
      newSession: async () => ({ cancelled: true }),
      fork: async () => ({ cancelled: true }),
      navigateTree: (targetId, options) =>
        this.navigateTreeKeepingToolSelection(targetId, { summarize: options?.summarize }),
      switchSession: async () => ({ cancelled: true }),
      reload: async () => {
        // As pi's TUI: a command runs inside its own prompt, so the pending
        // prompt does not count; only a streaming or compacting turn does.
        const busy = this.inner.isStreaming
          ? "Wait for the current response to finish before reloading."
          : this.inner.isCompacting
            ? "Wait for compaction to finish before reloading."
            : null;
        if (busy) {
          this.emit({
            type: "extension_ui_request",
            id: randomUUID(),
            method: "notify",
            notifyType: "warning",
            message: busy,
          } as ExtensionUiRequest as AgentEvent);
          return;
        }
        this.extensionStatuses.clear();
        this.resetExtensionWidgetsForReload();
        this.syncProjectTrust();
        await this.inner.reload({
          beforeSessionStart: () => {
            this.inner.extensionRunner.setUIContext?.(this.createExtensionUiContext(), "rpc");
          },
        });
        // As the `reload` command: the provider lists' runtime follows.
        invalidateModelRuntimeWithExtensions();
      },
    };
  }

  private syncProjectTrust(): void {
    const status = getProjectTrustStatus(this.cwd, getAgentDir());
    this.inner.settingsManager.setProjectTrusted(status.trusted);
  }
}

// ============================================================================
// Session registry
// ============================================================================

declare global {
  var __piSessions: Map<string, AgentSessionWrapper> | undefined;
  var __piStartLocks: Map<string, Promise<{ session: AgentSessionWrapper; realSessionId: string }>> | undefined;
  /** Debug panel: the id a `__new__…`/`__recreate__…` start registered its wrapper under, while its lock is held. */
  var __piStartRegisteredIds: Map<string, string> | undefined;
  var __piStartingSessionCwds: Map<string, number> | undefined;
}

function getRegistry(): Map<string, AgentSessionWrapper> {
  if (!globalThis.__piSessions) {
    globalThis.__piSessions = new Map();
    const destroy = () => globalThis.__piSessions?.forEach((session) => session.destroy());
    const shutdown = () => {
      const sessions = Array.from(globalThis.__piSessions?.values() ?? []);
      void Promise.allSettled(sessions.map((session) => session.shutdown()));
    };
    // Node cannot await work from an exit handler; direct destruction starts
    // extension cleanup synchronously as a final best effort.
    process.once("exit", destroy);
    process.once("SIGINT", shutdown);
    process.once("SIGTERM", shutdown);
  }
  return globalThis.__piSessions;
}

/**
 * Each session id's wrapper starts and last close, for the debug panel: a wrapper reaped and
 * rebuilt reads apart from one that stayed up. On globalThis, as the registry, so a hot reload
 * keeps it; bounded, oldest first, never dropping an id that still has a wrapper.
 */
const SESSION_LIFECYCLE_KEY = Symbol.for("pi-web:session-lifecycle");
const SESSION_LIFECYCLE_LIMIT = 1000;

function readSessionLifecycles(): Map<string, DebugSessionLifecycle> | null {
  const existing = (globalThis as Record<PropertyKey, unknown>)[SESSION_LIFECYCLE_KEY];
  return existing instanceof Map ? existing as Map<string, DebugSessionLifecycle> : null;
}

// Bookkeeping only: a failure here must never keep a wrapper from starting.
function recordSessionStart(sessionId: string): void {
  try {
    let lifecycles = readSessionLifecycles();
    if (!lifecycles) {
      lifecycles = new Map();
      (globalThis as Record<PropertyKey, unknown>)[SESSION_LIFECYCLE_KEY] = lifecycles;
    }
    const now = Date.now();
    const previous = lifecycles.get(sessionId);
    lifecycles.delete(sessionId);
    lifecycles.set(sessionId, {
      starts: (typeof previous?.starts === "number" ? previous.starts : 0) + 1,
      firstStartedAt: typeof previous?.firstStartedAt === "number" ? previous.firstStartedAt : now,
      lastStartedAt: now,
      lastClosedAt: typeof previous?.lastClosedAt === "number" ? previous.lastClosedAt : null,
    });
    const sessions = globalThis.__piSessions;
    for (const id of lifecycles.keys()) {
      if (lifecycles.size <= SESSION_LIFECYCLE_LIMIT) break;
      if (id !== sessionId && !sessions?.has(id)) lifecycles.delete(id);
    }
  } catch {
    // The panel shows no history for this id.
  }
}

// Called from finishDispose(): it must never throw past resolveDisposed().
function recordSessionClosed(wrapper: { readonly sessionId: string }): void {
  try {
    const lifecycle = readSessionLifecycles()?.get(wrapper.sessionId);
    if (lifecycle) lifecycle.lastClosedAt = Date.now();
  } catch {
    // The panel shows no close time for this id.
  }
}

function registerRpcWrapper(wrapper: AgentSessionWrapper): void {
  const registry = getRegistry();
  const sessionId = wrapper.sessionId;
  if (wrapper.sessionFile) cacheSessionPath(sessionId, wrapper.sessionFile);
  // A closing wrapper reports itself dead while extensions shut down, so the
  // next request registers a replacement under the same id. Finishing later,
  // the closing wrapper must not unregister that replacement.
  wrapper.onDestroy(() => {
    if (registry.get(sessionId) === wrapper) registry.delete(sessionId);
  });
  // A wrapper registered before a hot reload still unregisters by id alone.
  const previous = registry.get(sessionId);
  if (previous && previous !== wrapper && typeof previous.onDestroy === "function") {
    previous.onDestroy(() => {});
  }
  recordSessionStart(sessionId);
  registry.set(sessionId, wrapper);
  wrapper.start();
  if (!wrapper.isChatOnly()) wrapper.beginExtensionBinding();
}

const SUBAGENT_CONTROLLER = createSubagentController({
  getSession: (sessionId) => getRegistry().get(sessionId),
  registerSession: (inner, options) => {
    const wrapper = new AgentSessionWrapper(inner, {
      ...(options?.exactSystemPrompt !== undefined
        ? { exactSystemPrompt: options.exactSystemPrompt }
        : {}),
      chatOnly: options?.chatOnly,
      suppressCompletionNotifications: true,
      ...(options?.mcpHost ? { mcpHost: options.mcpHost } : {}),
    });
    registerRpcWrapper(wrapper);
    return wrapper;
  },
  reopenSession: async (sessionId, sessionFile) =>
    (await startRpcSession(sessionId, sessionFile, undefined)).session,
  resolveSessionPath,
  invalidateSessionList: invalidateSessionListCache,
  isBuiltInSubagentsEnabled,
});

export function getSubagentRun(sessionId: string) {
  return SUBAGENT_CONTROLLER.get(sessionId);
}

export function steerSubagent(sessionId: string, message: string) {
  return SUBAGENT_CONTROLLER.steer(sessionId, message);
}

export function abortSubagent(sessionId: string) {
  return SUBAGENT_CONTROLLER.abort(sessionId);
}

function getLocks(): Map<string, Promise<{ session: AgentSessionWrapper; realSessionId: string }>> {
  if (!globalThis.__piStartLocks) globalThis.__piStartLocks = new Map();
  return globalThis.__piStartLocks;
}

// Bookkeeping for getRpcStartingSessionIds() only: a failure here must never fail a start.
function recordStartRegisteredId(startKey: string, realSessionId: string): void {
  try {
    if (startKey === realSessionId) return;
    if (!(globalThis.__piStartRegisteredIds instanceof Map)) globalThis.__piStartRegisteredIds = new Map();
    globalThis.__piStartRegisteredIds.set(startKey, realSessionId);
  } catch {
    // The panel counts this start as starting until its lock goes.
  }
}

function forgetStartRegisteredId(startKey: string): void {
  try {
    const registered = globalThis.__piStartRegisteredIds;
    if (registered instanceof Map) registered.delete(startKey);
  } catch {
    // Nothing reads a key whose lock is gone.
  }
}

const CLOSING_SESSION_WAIT_MARGIN_MS = 1_000;
const closingSessionWaits = new WeakMap<AgentSessionWrapper, { done: boolean; promise: Promise<void> }>();

/**
 * The wait for a wrapper of `sessionId` that is shutting down, or null when there is none
 * left to wait for. Until it is disposed the closing wrapper still owns the session: an
 * extension's session_shutdown may append to the file, which a replacement opened earlier
 * would branch away from, and dispose() releases provider resources (a Codex websocket) by
 * session id, which the replacement shares. The wait is bounded so a shutdown stuck in
 * extension binding cannot keep the session from starting again. One wait per closing
 * wrapper: its bound runs from the first caller and later callers share it, so a
 * shutdown still binding extensions can be overtaken.
 */
function closingRpcSessionWait(sessionId: string): Promise<void> | null {
  const closing = getRegistry().get(sessionId);
  // A wrapper from before a hot reload may lack waitUntilDisposed.
  if (!closing || closing.isAlive() || typeof closing.waitUntilDisposed !== "function") return null;
  let wait = closingSessionWaits.get(closing);
  if (!wait) {
    const entry = { done: false, promise: Promise.resolve() };
    entry.promise = closing.waitUntilDisposed(SESSION_SHUTDOWN_DEADLINE_MS + CLOSING_SESSION_WAIT_MARGIN_MS)
      .then((disposed) => {
        if (!disposed) console.warn(`[pi-web] session ${sessionId} is still shutting down; starting it again anyway`);
      })
      .finally(() => { entry.done = true; });
    closingSessionWaits.set(closing, entry);
    wait = entry;
  }
  return wait.done ? null : wait.promise;
}

function normalizeRpcCwd(cwd: string): string {
  const resolvedCwd = resolve(cwd);
  try {
    return realpathSync(resolvedCwd);
  } catch {
    return resolvedCwd;
  }
}

function getStartingSessionCwds(): Map<string, number> {
  if (!globalThis.__piStartingSessionCwds) globalThis.__piStartingSessionCwds = new Map();
  return globalThis.__piStartingSessionCwds;
}

function trackStartingSession(cwd: string): () => void {
  const startingCwds = getStartingSessionCwds();
  const key = normalizeRpcCwd(cwd);
  startingCwds.set(key, (startingCwds.get(key) ?? 0) + 1);
  return () => {
    const remaining = (startingCwds.get(key) ?? 1) - 1;
    if (remaining > 0) startingCwds.set(key, remaining);
    else startingCwds.delete(key);
  };
}

export function getRpcSession(sessionId: string): AgentSessionWrapper | undefined {
  return getRegistry().get(sessionId);
}

/**
 * The sidebar's rename (#1388). A session a wrapper holds is renamed through
 * `AgentSession.setSessionName()`, as pi's `/name`, so the `session_info` entry hangs off the live
 * leaf and extensions get `session_info_changed`; appended to the file from outside, it was a dead
 * branch the running session never saw. Like the `set_session_name` command it does not wait for
 * session_start: handlers are registered at load, and a session_start that never settles (an
 * unanswered dialog) must not hold the rename. A start in flight is awaited (its `SessionManager`
 * has already read the file), as is a wrapper shutting down (its extensions may still append from
 * its leaf). With no wrapper and no start, `writeToDisk` runs synchronously right after that check,
 * so nothing can open the file between the two. Resolves what `writeToDisk` returns, or true.
 */
export async function renameRpcSession(sessionId: string, name: string, writeToDisk: () => boolean): Promise<boolean> {
  for (;;) {
    const wrapper = getRegistry().get(sessionId);
    if (wrapper?.isAlive()) {
      wrapper.inner.setSessionName(name);
      invalidateSessionListCache();
      return true;
    }
    const pending = getLocks().get(sessionId) ?? closingRpcSessionWait(sessionId);
    if (!pending) return writeToDisk();
    await pending.catch(() => undefined);
  }
}

export interface SetRpcSessionToolsResult {
  session: AgentSessionWrapper;
  sessionId: string;
  recreated: boolean;
}

/**
 * Persist a normal session's tool selection and rebuild when resource policy changes.
 * An undefined requestedToolNames returns the session to pi's configured defaults:
 * the pin is retracted and the session is rebuilt, because the loadout that
 * settings.json defaultTools resolves to is only known once pi builds the session.
 */
export async function setRpcSessionTools(
  sessionId: string,
  sessionFile: string | undefined,
  requestedToolNames: unknown,
): Promise<SetRpcSessionToolsResult> {
  const toolNames = requestedToolNames === undefined
    ? undefined
    : validateSessionToolSelection(requestedToolNames);
  const existing = getRpcSession(sessionId);

  if (!existing?.isAlive()) {
    if (!sessionFile) throw new Error("Session not found");
    // A wrapper still closing, or a start already under way, owns the file: wait for it and
    // apply the selection to whatever it left, or a start that opened the file first would
    // come up without the selection while this call reported success.
    const pending = closingRpcSessionWait(sessionId) ?? getLocks().get(sessionId);
    if (pending) {
      await pending.catch(() => undefined);
      return setRpcSessionTools(sessionId, sessionFile, requestedToolNames);
    }
    const manager = SessionManager.open(sessionFile, undefined);
    if (readSubagentSessionResources(manager.getEntries() as unknown as SessionEntry[])) {
      throw new Error("Subagent tool selection is fixed by its profile");
    }
    if (toolNames === undefined) appendClearedSessionToolSelection(manager);
    else appendSessionToolSelection(manager, toolNames);
    invalidateSessionListCache();
    const started = await startRpcSession(sessionId, sessionFile, undefined);
    return { session: started.session, sessionId: started.realSessionId, recreated: false };
  }

  if (existing.isRunning()) throw new Error("Cannot change tools while the session is running");
  if (readSubagentSessionResources(existing.inner.sessionManager.getEntries() as unknown as SessionEntry[])) {
    throw new Error("Subagent tool selection is fixed by its profile");
  }

  const hasCurrentResourcePolicy = typeof existing.isChatOnly === "function"
    && typeof existing.setActiveToolSelection === "function";
  const crossesChatOnlyBoundary = toolNames === undefined
    || !hasCurrentResourcePolicy
    || existing.isChatOnly() !== (toolNames.length === 0);
  if (toolNames === undefined) appendClearedSessionToolSelection(existing.inner.sessionManager);
  else appendSessionToolSelection(existing.inner.sessionManager, toolNames);
  invalidateSessionListCache();

  if (toolNames !== undefined && !crossesChatOnlyBoundary) {
    existing.setActiveToolSelection(toolNames);
    return { session: existing, sessionId, recreated: false };
  }

  const persistedFile = existing.sessionFile && existsSync(existing.sessionFile)
    ? existing.sessionFile
    : undefined;
  const sessionCwd = existing.cwd;
  const model = existing.inner.model;
  const currentThinkingLevel = existing.inner.agent.state?.thinkingLevel;
  await existing.shutdown();

  if (persistedFile) {
    const started = await startRpcSession(sessionId, persistedFile, undefined);
    return { session: started.session, sessionId: started.realSessionId, recreated: true };
  }

  const started = await startRpcSession(`__recreate__${randomUUID()}`, "", sessionCwd, {
    ...(toolNames !== undefined ? { toolNames } : {}),
    ...(model ? { initialModel: { provider: model.provider, modelId: model.id } } : {}),
    allowInitialModelFallback: true,
    ...(currentThinkingLevel && THINKING_LEVEL_NAMES.has(currentThinkingLevel as ThinkingLevel)
      ? { thinkingLevel: currentThinkingLevel as ThinkingLevel }
      : {}),
  });
  return { session: started.session, sessionId: started.realSessionId, recreated: true };
}

function runtimeMessageText(entry: SessionMessageEntry): string {
  if (entry.message.role === "bashExecution") return "";
  const content = entry.message.content;
  if (typeof content === "string") return content;
  return content
    .map((block) => block.type === "text" ? block.text : "")
    .filter(Boolean)
    .join(" ");
}

function runtimeMessageActivityMs(entry: SessionMessageEntry): number | undefined {
  if (entry.message.role !== "user" && entry.message.role !== "assistant") return undefined;
  if (typeof entry.message.timestamp === "number") return entry.message.timestamp;
  const timestamp = new Date(entry.timestamp).getTime();
  return Number.isNaN(timestamp) ? undefined : timestamp;
}

/**
 * A subagent's status as the session list and viewer show it. Only this process can finish a
 * run, so a running wrapper or the live run map decides; a persisted `running` / `queued` with
 * neither was left by a process that stopped mid-run and reads as `interrupted`, as
 * `get_subagent_result` reports it. Applied per response, never to the cached scan.
 */
export function subagentDisplayStatus(sessionId: string, persisted: SubagentSessionStatus): SubagentSessionStatus {
  if (getRegistry().get(sessionId)?.isRunning()) return "running";
  return getLiveSubagentStatus(sessionId) ?? settleOrphanedSubagentStatus(persisted);
}

export function withSubagentDisplayStatus(sessions: SessionInfo[]): SessionInfo[] {
  return sessions.map((session) => {
    const relation = session.relation;
    if (relation?.kind !== "subagent") return session;
    const status = subagentDisplayStatus(session.id, relation.status);
    return status === relation.status ? session : { ...session, relation: { ...relation, status } };
  });
}

/**
 * Return live sessions that should be visible in the session list. Pi delays
 * the first JSONL flush until an assistant message exists, so an accepted new
 * prompt must temporarily be described from its in-memory SessionManager.
 */
export function getRpcSessionInfos(options: { includeTransient?: boolean } = {}): SessionInfo[] {
  const sessions: SessionInfo[] = [];
  for (const session of getRegistry().values()) {
    if (typeof session.isAlive !== "function" || !session.isAlive()) continue;

    const manager = session.inner?.sessionManager;
    if (!manager) continue;
    const header = manager.getHeader();
    const entries = manager.getEntries() as unknown as Array<
      { type: string; timestamp: string } | SessionMessageEntry
    >;
    const messages = entries.filter((entry): entry is SessionMessageEntry => entry.type === "message");
    const firstUserMessage = messages.find((entry) => entry.message.role === "user");
    const sessionFile = manager.getSessionFile() ?? session.sessionFile;
    const persisted = Boolean(sessionFile && existsSync(sessionFile));
    const subagent = readSubagentRun(entries as unknown as SessionEntry[], header?.id ?? session.sessionId, sessionFile ?? "");

    // An ensure_session call creates an idle, empty runtime while the composer
    // loads commands. Do not leak it into history before a prompt is accepted.
    if (!persisted && !options.includeTransient && (!session.isRunning() || !firstUserMessage)) continue;

    const created = header?.timestamp
      ?? entries[0]?.timestamp
      ?? new Date().toISOString();
    const headerTimestamp = new Date(created).getTime();
    let lastActivityMs = Number.isNaN(headerTimestamp) ? Date.now() : headerTimestamp;
    for (const message of messages) {
      const activityMs = runtimeMessageActivityMs(message);
      if (activityMs !== undefined) lastActivityMs = Math.max(lastActivityMs, activityMs);
    }

    sessions.push({
      path: sessionFile ?? "",
      id: header?.id ?? session.sessionId,
      cwd: header?.cwd ?? session.cwd,
      name: manager.getSessionName(),
      created,
      modified: new Date(lastActivityMs).toISOString(),
      messageCount: messages.length,
      firstMessage: catalogFirstMessage(firstUserMessage ? runtimeMessageText(firstUserMessage) || "(no messages)" : "(no messages)"),
      ...(subagent ? {
        parentSessionId: subagent.parentSessionId,
        relation: {
          kind: "subagent" as const,
          parentSessionId: subagent.parentSessionId,
          profile: subagent.profile,
          description: subagent.description,
          status: session.isRunning() ? "running" as const : subagent.status,
        },
      } : {}),
      transient: !persisted,
    });
  }
  return sessions;
}

export function hasBusyRpcSessionForCwd(cwd: string): boolean {
  const targetCwd = normalizeRpcCwd(cwd);
  if (getStartingSessionCwds().has(targetCwd)) return true;
  return Array.from(getRegistry().values()).some(
    (session) => normalizeRpcCwd(session.cwd) === targetCwd && session.isRunning(),
  );
}

export async function destroyRpcSessionsForCwd(cwd: string): Promise<number> {
  const targetCwd = normalizeRpcCwd(cwd);
  const sessions = Array.from(getRegistry().values()).filter(
    (session) => normalizeRpcCwd(session.cwd) === targetCwd,
  );
  await Promise.all(sessions.map((session) => session.shutdown()));
  return sessions.length;
}

export function getRunningRpcSessionIds(): string[] {
  const ids = new Set<string>();
  for (const [sessionId, session] of getRegistry()) {
    if (session.isRunning()) ids.add(session.sessionId || sessionId);
  }
  return [...ids];
}

/**
 * The running sessions parked on an extension's dialog, a subset of
 * getRunningRpcSessionIds(): same poll, so the sidebar can tell a run that needs
 * a person from one that is still working.
 */
export function getAwaitingInputRpcSessionIds(): string[] {
  const ids = new Set<string>();
  for (const [sessionId, session] of getRegistry()) {
    if (session.isAwaitingInput()) ids.add(session.sessionId || sessionId);
  }
  return [...ids];
}

/** One registered wrapper as the debug panel reads it (lib/debug-snapshot.ts). */
export interface RpcSessionDebugEntry {
  snapshot: DebugWrapperSnapshot;
  /** Matches liveness providers registered by file; never sent to the browser. */
  sessionFile: string | null;
  /** The MCP host's state; read for the session the panel shows only. */
  readMcp(): DebugMcpHost | null;
}

type MaybeStaleWrapper = Partial<Pick<AgentSessionWrapper, "isAlive" | "isRunning" | "getDebugSnapshot" | "getMcpDebugSnapshot">>;

/** A wrapper built before a hot reload has no getDebugSnapshot(): only state and running are known. */
function staleWrapperSnapshot(sessionId: string, wrapper: MaybeStaleWrapper): DebugWrapperSnapshot {
  let alive = false;
  let running = false;
  try { alive = typeof wrapper.isAlive === "function" && wrapper.isAlive() === true; } catch { /* unknown: closing */ }
  try { running = typeof wrapper.isRunning === "function" && wrapper.isRunning() === true; } catch { /* unknown: idle */ }
  return {
    sessionId,
    state: alive ? "alive" : "closing",
    stale: true,
    subagent: false,
    chatOnly: false,
    createdAt: null,
    startedAt: null,
    closingAt: null,
    extensions: "none",
    run: {
      running,
      streaming: false,
      promptRunning: false,
      pendingPrompts: 0,
      bashRunning: false,
      compacting: false,
      retrying: false,
      queuedMessages: 0,
      waitingForMcp: false,
      runningTools: 0,
      mutatingCommands: 0,
      replacement: null,
    },
    idle: { timeoutMs: SESSION_IDLE_TIMEOUT_MS, nextCheckAt: null, lastResetAt: null, forcedByStop: false },
    awaitingInput: false,
    pendingUiRequests: 0,
    customUis: 0,
    eventListeners: 0,
    lastEvent: null,
    lastCommand: null,
  };
}

/**
 * Every registered wrapper, closing ones included, for the debug panel. Reads the registry
 * global itself (getRegistry() installs process handlers) and only reads each wrapper: one
 * that fails to describe itself is listed as stale rather than failing the rest.
 */
export function getRpcSessionDebugSnapshots(): RpcSessionDebugEntry[] {
  const registry = globalThis.__piSessions;
  if (!(registry instanceof Map)) return [];
  const entries: RpcSessionDebugEntry[] = [];
  for (const [key, session] of registry) {
    const wrapper = session as MaybeStaleWrapper & { readonly sessionFile?: unknown };
    let snapshot: DebugWrapperSnapshot;
    try {
      snapshot = typeof wrapper.getDebugSnapshot === "function"
        ? wrapper.getDebugSnapshot()
        : staleWrapperSnapshot(key, wrapper);
    } catch {
      snapshot = staleWrapperSnapshot(key, wrapper);
    }
    if (!snapshot.sessionId) snapshot = { ...snapshot, sessionId: key };
    let sessionFile: string | null = null;
    try {
      sessionFile = typeof wrapper.sessionFile === "string" && wrapper.sessionFile ? wrapper.sessionFile : null;
    } catch { /* matched by id only */ }
    entries.push({
      snapshot,
      sessionFile,
      readMcp: () => typeof wrapper.getMcpDebugSnapshot === "function" ? wrapper.getMcpDebugSnapshot() : null,
    });
  }
  return entries;
}

/** The start and close history of a session id; null when no wrapper was started for it. */
export function getRpcSessionLifecycle(sessionId: string): DebugSessionLifecycle | null {
  const lifecycle = readSessionLifecycles()?.get(sessionId);
  if (!lifecycle || typeof lifecycle.starts !== "number") return null;
  return {
    starts: lifecycle.starts,
    firstStartedAt: lifecycle.firstStartedAt,
    lastStartedAt: lifecycle.lastStartedAt,
    lastClosedAt: lifecycle.lastClosedAt ?? null,
  };
}

/**
 * The startRpcSession() calls under way with no alive wrapper yet: a lock outlives the
 * wrapper's registration while a deferred model is switched to. `__new__…` and
 * `__recreate__…` keys name a start whose id pi has not chosen yet; once its wrapper is
 * registered, the key is looked up under that id.
 */
export function getRpcStartingSessionIds(): string[] {
  const locks = globalThis.__piStartLocks;
  if (!(locks instanceof Map)) return [];
  const sessions = globalThis.__piSessions;
  const registered = globalThis.__piStartRegisteredIds;
  const ids: string[] = [];
  for (const key of locks.keys()) {
    const registeredId = registered instanceof Map ? registered.get(key) : undefined;
    const id = typeof registeredId === "string" && registeredId ? registeredId : key;
    const wrapper = sessions instanceof Map ? sessions.get(id) as MaybeStaleWrapper | undefined : undefined;
    let alive = false;
    try { alive = typeof wrapper?.isAlive === "function" && wrapper.isAlive() === true; } catch { /* starting */ }
    if (!alive) ids.push(key);
  }
  return ids;
}

export function getCompletionNotificationSuppressedRpcSessionIds(): string[] {
  const ids = new Set<string>();
  for (const [sessionId, session] of getRegistry()) {
    if (session.isRunning() && session.hasSuppressedCompletionNotifications()) {
      ids.add(session.sessionId || sessionId);
    }
  }
  return [...ids];
}

/**
 * Get or create an AgentSession for the given session.
 * For new sessions (sessionFile === ""), pi generates its own id.
 * New sessions resolve enabledModels before construction so the initial model,
 * thinking pin, and SDK scopedModels share one settings snapshot.
 * Pass options.toolNames to pre-configure active tools (empty = all disabled).
 */
export async function startRpcSession(
  sessionId: string,
  sessionFile: string,
  cwd: string | undefined,
  options: RpcSessionStartOptions = {},
): Promise<{ session: AgentSessionWrapper; realSessionId: string }> {
  const { initialModel, allowInitialModelFallback, thinkingLevel } = options;
  const requestedToolNames = options.toolNames === undefined
    ? undefined
    : validateSessionToolSelection(options.toolNames);
  const registry = getRegistry();
  const locks = getLocks();

  const existing = registry.get(sessionId);
  if (existing?.isAlive()) return { session: existing, realSessionId: sessionId };

  const inflight = locks.get(sessionId);
  if (inflight) return inflight;

  const closingWait = closingRpcSessionWait(sessionId);
  if (closingWait) {
    // Concurrent starts share this lock, then the one start that follows it.
    const waiting: Promise<{ session: AgentSessionWrapper; realSessionId: string }> = closingWait.then(() => {
      if (locks.get(sessionId) === waiting) locks.delete(sessionId);
      return startRpcSession(sessionId, sessionFile, cwd, options);
    });
    locks.set(sessionId, waiting);
    return waiting;
  }

  let sessionManager: SessionManager;
  if (sessionFile) {
    sessionManager = SessionManager.open(sessionFile, undefined);
  } else {
    if (!cwd) throw new Error("cwd is required for a new session");
    sessionManager = SessionManager.create(cwd, undefined);
  }
  const sessionCwd = sessionManager.getCwd();
  const sessionEntries = sessionManager.getEntries() as unknown as SessionEntry[];
  const hasPersistedSubagentSnapshot = sessionFile && hasSubagentResourceSnapshot(sessionEntries);
  const subagentResources = sessionFile
    ? readSubagentSessionResources(sessionEntries)
    : null;
  if (hasPersistedSubagentSnapshot && !subagentResources) {
    throw new Error("Invalid subagent resource snapshot");
  }
  const persistedToolNames = subagentResources
    ? undefined
    : readSessionToolSelection(sessionEntries);
  const selectedToolNames = subagentResources?.tools ?? persistedToolNames ?? requestedToolNames;
  if (!subagentResources && persistedToolNames === undefined && requestedToolNames !== undefined) {
    appendSessionToolSelection(sessionManager, requestedToolNames);
  }
  const subagentLoadsResources = Boolean(
    subagentResources?.loadExtensions || subagentResources?.loadSkills || subagentResources?.codemode || subagentResources?.mcp,
  );
  const chatOnly = selectedToolNames?.length === 0 && !subagentLoadsResources;
  const finishStartingSession = trackStartingSession(sessionCwd);
  const starting = (async () => {
    // Some extensions access the SDK's global theme even outside the terminal UI.
    if (!chatOnly) initTheme();
    const agentDir = getAgentDir();

    // Determine which tools to pass based on requested toolNames.
    // Since v0.68.0, session creation expects string[] tool names instead of Tool[] instances.
    // A subagent's tools come from its snapshot (subagentToolOptions() below).
    let toolsOption: string[] | undefined;
    if (!subagentResources && selectedToolNames !== undefined) {
      // toolNames === [] -> "all off" (an empty allow-list disables every tool).
      // Otherwise DO NOT pass a builtin-only allow-list: passing CODING_TOOL_NAMES
      // set allowedToolNames to coding builtins only, which filtered every
      // extension/package-provided tool (e.g. subagents, web access) out of the
      // tool registry — so they were unavailable in Pi Web sessions even though the
      // `pi` CLI keeps them. Leaving the allow-list unset lets the SDK register all
      // tools (and activate extension tools); we narrow the ACTIVE set below.
      toolsOption = selectedToolNames.length === 0 ? [] : undefined;
    }

    // Build services first so extension-registered providers are available
    // before the SDK restores the saved model from the session file.
    // Gate untrusted project extensions so opening a repository does not run
    // its .pi/extensions code automatically (see lib/project-trust.ts, #236).
    const trustReloadOptions = subagentResources
      ? subagentLoadsResources
        ? projectTrustReloadOptions(sessionCwd, agentDir)
        : undefined
      : chatOnly
        ? undefined
        : projectTrustReloadOptions(sessionCwd, agentDir);
    const settingsManager = SettingsManager.create(sessionCwd, agentDir);
    // Chat-only sessions and subagents that replace Pi's prompt send an exact
    // system prompt. The prompt is resolved at prompt time through this inline
    // extension: it may read the session's context files, which exist only
    // after the session is created, so the getter is filled in below.
    const exactSystemPromptRef: { current?: () => string } = {};
    const exactSystemPromptExtension = createExactSystemPromptExtension(() => exactSystemPromptRef.current?.());
    // codemode, tool-search, and mcp, as the pi CLI loads them, and the host that decides
    // which MCP servers the session connects (ADR 0006).
    const builtins = subagentResources || chatOnly
      ? undefined
      : await createPiWebBuiltinExtensions({ agentDir });
    const subagentCodemode = subagentResources?.codemode
      ? await createSubagentCodemodeExtension({
          agentDir,
          cwd: sessionCwd,
          projectTrusted: () => settingsManager.isProjectTrusted(),
        })
      : undefined;
    const subagentMcp = subagentResources?.mcp
      ? await createSubagentMcpExtensions({
          agentDir,
          cwd: sessionCwd,
          projectTrusted: () => settingsManager.isProjectTrusted(),
          codemode: subagentResources.codemode === true,
        })
      : undefined;
    const skillsBinding = subagentResources ? createSubagentSkillsBinding({
      loadSkills: subagentResources.loadSkills,
      skills: subagentResources.skills,
      exactSystemPrompt: subagentResources.exactSystemPrompt
        ?? (chatOnly ? subagentResources.appendSystemPrompt[0] ?? "" : undefined),
    }) : undefined;
    const subagentExtensionFactories = [
      ...(subagentCodemode ? [subagentCodemode] : []),
      ...(subagentMcp && subagentResources
        ? [...subagentMcp.extensions, createSubagentMcpPolicyExtension(() => subagentResources)]
        : []),
      ...(skillsBinding?.loaderOptions.extensionFactories ?? []),
    ];
    const services = await createAgentSessionServices({
      cwd: sessionCwd,
      agentDir,
      settingsManager,
      resourceLoaderOptions: subagentResources
        ? {
            ...subagentExtensionLoaderOptions(subagentResources),
            ...skillsBinding!.loaderOptions,
            ...(subagentExtensionFactories.length > 0 ? { extensionFactories: subagentExtensionFactories } : {}),
            noPromptTemplates: true,
            noThemes: true,
            noContextFiles: true,
            ...(chatOnly
              ? {
                  systemPrompt: " ",
                  systemPromptOverride: () => undefined,
                }
              : {}),
            appendSystemPrompt: subagentResources.appendSystemPrompt,
          }
        : chatOnly
          ? { ...CHAT_ONLY_RESOURCE_LOADER_OPTIONS, extensionFactories: [exactSystemPromptExtension] }
        : {
            extensionFactories: [
              ...(builtins?.extensions ?? []),
              createReadOnlyMcpPolicyExtension(),
              createProjectCommandBashExtension({
                cwd: sessionCwd,
                settings: settingsManager,
              }),
              createSubagentExtension(
                SUBAGENT_CONTROLLER.extensionRuntime,
                () => listSubagentProfiles(sessionCwd),
                isBuiltInSubagentsEnabled,
              ),
            ],
            extensionsOverride: (base) => preferUserBashExtension(preferPiWebSubagentExtension(base)),
          },
      ...(trustReloadOptions ? { resourceLoaderReloadOptions: trustReloadOptions } : {}),
    });
    if (subagentResources?.codemode
      && !services.resourceLoader.getExtensions().extensions.some((extension) => extension.tools.has("codemode"))) {
      throw new Error("Code mode is unavailable: builtin:codemode was not registered");
    }
    const enabledModels = services.settingsManager.getEnabledModels();
    const scope = await resolveVisibleModels(services.modelRuntime, enabledModels);
    // A provider an extension registers only at session_start (lib/deferred-provider-models.ts)
    // has no model in this runtime yet: build on the default, switch once extensions are bound.
    const deferredInitialModel = initialModel && !services.modelRuntime.getModel(initialModel.provider, initialModel.modelId)
      ? findDeferredModel(services.modelRuntime, initialModel.provider, initialModel.modelId)
      : undefined;
    // Chat only loads no extensions, so that switch never comes: refuse the model the browser chose.
    if (chatOnly && deferredInitialModel && !allowInitialModelFallback) {
      throw chatOnlyExtensionModelError(deferredInitialModel.provider, deferredInitialModel.id);
    }
    const effectiveInitialModel = initialModel && !deferredInitialModel && (
      !allowInitialModelFallback
      || scope.visible.some((model) => model.provider === initialModel.provider && model.id === initialModel.modelId)
    )
      ? initialModel
      : undefined;
    const defaultProvider = services.settingsManager.getDefaultProvider();
    const defaultModelId = services.settingsManager.getDefaultModel();
    const defaultModel = defaultProvider && defaultModelId
      ? { provider: defaultProvider, modelId: defaultModelId }
      : undefined;
    const branch = sessionManager.getBranch();
    // System messages carry the prompt and tool loadout, not a conversation.
    const hasExistingMessages = branch.some((entry) => entry.type === "message" && entry.message.role !== "system");
    const savedModel = hasExistingMessages
      ? getLatestModelChange(branch as unknown as SessionEntry[])
      : null;
    const restoredModel = savedModel
      ? services.modelRuntime.getModel(savedModel.provider, savedModel.modelId)
      : undefined;
    const initial = hasExistingMessages ? null : selectInitialModelScope(scope, {
        ...(effectiveInitialModel ? { requestedModel: effectiveInitialModel } : {}),
        ...(defaultModel ? { defaultModel } : {}),
        ...(thinkingLevel ? { thinkingLevel } : {}),
      });
    const startupModel = restoredModel && services.modelRuntime.hasConfiguredAuth(restoredModel.provider)
      ? restoredModel
      : initial?.model;
    // A registered default the session starts on is in scope with deferred models counted too
    // (globs and exact entries only gain matches), unless the scope fell back to every model.
    const startsOnDefault = Boolean(initial?.model && defaultModel
      && initial.model.provider === defaultModel.provider && initial.model.id === defaultModel.modelId
      && (scope.scopedModels.length > 0 || !enabledModels?.some((pattern) => pattern.trim())));
    // pi's pick with deferred providers counted in, as /api/models shows it (#1240): a deferred
    // model asked for gets its enabledModels pin; with no usable model asked for, the browser shows
    // that pick and sends none, so a deferred pick is switched to as well.
    const deferredStartup = !hasExistingMessages && !chatOnly && (deferredInitialModel || (!effectiveInitialModel && !startsOnDefault))
      ? await findDeferredStartupModel(services.modelRuntime, enabledModels, deferredInitialModel
        ? { requestedModel: { provider: deferredInitialModel.provider, modelId: deferredInitialModel.id } }
        : defaultModel ? { defaultModel } : {})
      : undefined;
    const deferredModel = hasExistingMessages
      ? savedModel && !restoredModel
        ? findDeferredModel(services.modelRuntime, savedModel.provider, savedModel.modelId)
        : undefined
      : deferredInitialModel ?? deferredStartup?.model;
    // set_model applies the model's modelThinkingLevels entry, else defaultThinkingLevel, else keeps
    // the current level: the stand-in model's (clamped, or its own pin). Apply what pi's
    // createAgentSession gives this model at startup instead: a resumed session's last saved level,
    // else the default; a new one's requested level, else the model's enabledModels pin, its
    // modelThinkingLevels entry, else the default.
    const deferredThinkingLevel = !deferredModel
      ? undefined
      : hasExistingMessages
        ? (branch.findLast((entry) => entry.type === "thinking_level_change")?.thinkingLevel as ThinkingLevel | undefined)
          ?? services.settingsManager.getDefaultThinkingLevel()
          ?? SDK_DEFAULT_THINKING_LEVEL
        : thinkingLevel
          ?? deferredStartup?.thinkingLevelPin
          ?? services.settingsManager.getModelThinkingLevel(deferredModel.provider, deferredModel.id)
          ?? services.settingsManager.getDefaultThinkingLevel()
          ?? SDK_DEFAULT_THINKING_LEVEL;
    // The extension's model a Chat-only session wanted (saved, chosen or default); a prompt names
    // it when the session ended up with no model at all.
    const chatOnlyExtensionModel = chatOnly
      ? deferredModel ?? (!hasExistingMessages && defaultProvider && defaultModelId
        ? findDeferredModel(services.modelRuntime, defaultProvider, defaultModelId)
        : undefined)
      : undefined;
    const { session: inner } = await createAgentSessionFromServices({
      services,
      sessionManager,
      ...(startupModel ? { model: startupModel } : {}),
      ...(initial?.thinkingLevel ? { thinkingLevel: initial.thinkingLevel } : {}),
      ...(scope.scopedModels.length > 0 ? { scopedModels: [...scope.scopedModels] } : {}),
      ...(subagentResources
        ? subagentToolOptions(subagentResources)
        : toolsOption !== undefined ? { tools: toolsOption } : {}),
    });

    // A pinned selection replaces only the coding tools of the SDK's initial loadout, which
    // already holds the extension tools pi activates on registration and whatever
    // `defaultTools` names (such as `+codemode`), so installed extensions stay usable in
    // Pi Web just like in the `pi` CLI.
    if (!subagentResources && !chatOnly) {
      const initialToolNames = inner.getActiveToolNames();
      inner.setActiveToolsByName(
        resolveActiveToolNames(inner, selectedToolNames ?? initialToolNames, initialToolNames),
      );
    }

    skillsBinding?.setActiveToolsGetter(() => inner.getActiveToolNames());
    const exactSystemPrompt = subagentResources
      ? skillsBinding!.getExactSystemPrompt
      : chatOnly
        ? () => contextFilesSystemPrompt(inner.resourceLoader.getAgentsFiles().agentsFiles)
        : undefined;
    exactSystemPromptRef.current = exactSystemPrompt;
    const mcpHost = builtins?.mcpHost ?? subagentMcp?.mcpHost;
    const wrapper = new AgentSessionWrapper(inner, {
      exactSystemPrompt,
      chatOnly,
      onAgentRunComplete: (completedSessionId, sessionName) => {
        void notifySessionComplete(completedSessionId, sessionName).catch((error) => {
          console.error("[pi-web] failed to send completion push:", error instanceof Error ? error.message : error);
        });
      },
      suppressCompletionNotifications: Boolean(subagentResources),
      ...(mcpHost ? { mcpHost } : {}),
      ...(chatOnlyExtensionModel ? { chatOnlyExtensionModel } : {}),
    });
    const realSessionId = inner.sessionId as string;
    registerRpcWrapper(wrapper);
    recordStartRegisteredId(sessionId, realSessionId);

    if (!chatOnly) {
      if (deferredModel) {
        try {
          await wrapper.waitUntilReady();
          await wrapper.send({ type: "set_model", provider: deferredModel.provider, modelId: deferredModel.id });
          if (deferredThinkingLevel) await wrapper.send({ type: "set_thinking_level", level: deferredThinkingLevel });
        } catch (error) {
          console.error(`[pi-web] could not switch to ${deferredModel.provider}/${deferredModel.id}:`, error instanceof Error ? error.message : error);
        }
      }
      // Bound extensions may have registered providers a later model listing will not see.
      void wrapper.waitUntilReady()
        .then(() => rememberProviderModels(inner.modelRuntime as ModelRuntime))
        .catch(() => undefined);
    }

    return { session: wrapper, realSessionId };
  })().finally(() => {
    locks.delete(sessionId);
    forgetStartRegisteredId(sessionId);
    finishStartingSession();
  });

  locks.set(sessionId, starting);
  return starting;
}
