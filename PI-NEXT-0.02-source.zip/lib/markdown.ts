import type { Content, Link, Parent, Root } from "mdast";
import type { Element as HastElement, Root as HastRoot, RootContent as HastContent } from "hast";
import { defaultUrlTransform, type Options as ReactMarkdownOptions } from "react-markdown";
import rehypeKatex from "rehype-katex";
import rehypeRaw from "rehype-raw";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
import remarkFrontmatter from "remark-frontmatter";
import remarkGfm from "remark-gfm";
import remarkCjkFriendly from "remark-cjk-friendly/parseOnly";
import remarkMath from "remark-math";
import type { Plugin } from "unified";
import type { Extension } from "micromark-util-types";

// Link schemes of desktop apps that open a note, a file or a meeting (#1108).
// A fixed list, not "any scheme but javascript:": the text comes from the model
// and from repository files, and OS handlers such as ms-msdt: or search-ms:
// have been exploited through a clicked link.
const appLinkSchemes = [
  "obsidian", "logseq", "notion",
  "vscode", "vscode-insiders", "cursor", "zed", "jetbrains",
  "zoommtg", "zoomus", "msteams", "slack",
];
const appLinkPattern = new RegExp(`^(?:${appLinkSchemes.join("|")}):`, "i");

// The anti-clobber prefix the sanitizer puts in front of every `id` in
// rendered content, so untrusted Markdown cannot shadow the page's own
// elements. The fragment-link fix below must use the identical value, so the
// schema that produces the prefixed ids pins the same constant.
const markdownClobberPrefix = defaultSchema.clobberPrefix ?? "user-content-";

const markdownSanitizeSchema = {
  ...defaultSchema,
  clobberPrefix: markdownClobberPrefix,
  attributes: {
    ...defaultSchema.attributes,
    code: [["className", /^language-./, "math-inline", "math-display"]],
  },
  protocols: {
    ...defaultSchema.protocols,
    href: [...(defaultSchema.protocols?.href ?? []), "file", ...appLinkSchemes],
  },
  strip: [...(defaultSchema.strip || []), "iframe", "object", "style", "form"],
};

/** react-markdown's URL filter, plus links to the apps above. */
export function markdownAppUrlTransform(value: string): string {
  return appLinkPattern.test(value) ? value : defaultUrlTransform(value);
}

/** Also keeps `file:` links, for renderers that open local files in the app. */
export function markdownUrlTransform(value: string): string {
  return /^file:/i.test(value) ? value : markdownAppUrlTransform(value);
}

/** A link that leaves the page: it names a scheme or another host. */
export function isExternalMarkdownHref(href: string | undefined): boolean {
  return Boolean(href && /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(href));
}

interface MarkdownFragmentClick {
  defaultPrevented: boolean;
  button: number;
  metaKey: boolean;
  ctrlKey: boolean;
  shiftKey: boolean;
  altKey: boolean;
  currentTarget: Pick<Element, "getAttribute" | "closest">;
  preventDefault(): void;
}

/**
 * A click on a `#fragment` link in rendered Markdown: brings the element it
 * names into view within the same rendered document (the closest
 * `.markdown-body`), as the Skills reader does with its headings. The browser's
 * own jump searches the whole page, where every chat message with a footnote
 * has its own `user-content-user-content-fn-1` and the file preview sits beside
 * the chat, so it could land in another message; it would also put the
 * fragment in the app's URL as a history entry. Modified clicks stay the
 * browser's.
 */
export function jumpToMarkdownFragment(event: MarkdownFragmentClick): void {
  if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  const href = event.currentTarget.getAttribute("href");
  if (!href?.startsWith("#")) return;
  event.preventDefault();
  let id = href.slice(1);
  if (!id) return;
  try {
    id = decodeURIComponent(id);
  } catch {
    // A malformed escape is matched as written.
  }
  const name = CSS.escape(id);
  event.currentTarget.closest(".markdown-body")
    ?.querySelector(`[id="${name}"], a[name="${name}"]`)
    ?.scrollIntoView({ block: "start" });
}

/**
 * `value.replace(pattern, replace)` as if `pattern` began with the lookbehind
 * `(?<![notAfter])`: a match starts with `opener` and must not follow any
 * character of `notAfter`. Safari only parses lookbehind from 16.4, and one
 * regex literal it cannot parse fails the whole script chunk, which left iOS
 * 16.2 on a blank page (#753). The sticky `pattern` is tried at each `opener`
 * in turn, the order in which the lookbehind version tries start positions.
 */
function replaceNotPrecededBy(
  value: string,
  opener: string,
  notAfter: string,
  pattern: RegExp,
  replace: (match: RegExpExecArray) => string,
): string {
  let result = "";
  let copied = 0;
  for (let index = value.indexOf(opener); index !== -1; index = value.indexOf(opener, index + 1)) {
    if (index > 0 && notAfter.includes(value[index - 1])) continue;
    pattern.lastIndex = index;
    const match = pattern.exec(value);
    if (!match) continue;
    result += value.slice(copied, index) + replace(match);
    copied = pattern.lastIndex;
    index = copied - 1;
  }
  return result + value.slice(copied);
}

// The closing backtick must not follow `\` or another backtick, so the content
// ends with a character that is neither.
const escapedInlineCodePattern = /`((?:[^`\n]|\\`)*?[^\\`\n])`(?!`)/y;

function rewriteEscapedInlineCodeBackticks(line: string): string {
  return replaceNotPrecededBy(line, "`", "\\`", escapedInlineCodePattern, ([match, content]) => {
    const code = content.replace(/\\`/g, "`");
    if (code === content) return match;
    const marker = "`".repeat(Math.max(...(code.match(/`+/g)?.map((run) => run.length) ?? [0])) + 1);
    return `${marker}${code}${marker}`;
  });
}

export function normalizeDisplayMath(markdown: string): string {
  const lineBreak = markdown.includes("\r\n") ? "\r\n" : "\n";
  const lines = markdown.split(/\r?\n/);
  const normalized: string[] = [];
  let fence: { marker: string; size: number } | null = null;
  let inlineCodeMarkerSize = 0;
  let rawCodeTag: string | null = null;
  const unmatchedDisplayMathUntil = new Map<string, number>();

  for (let index = 0; index < lines.length; index++) {
    let line = lines[index];

    if (rawCodeTag) {
      normalized.push(line);
      if (new RegExp(`</${rawCodeTag}\\s*>`, "i").test(line)) rawCodeTag = null;
      continue;
    }

    const fenceMatch = line.match(/^ {0,3}(`{3,}|~{3,})/);
    if (fenceMatch) {
      const marker = fenceMatch[1][0];
      const size = fenceMatch[1].length;
      if (!fence) fence = { marker, size };
      else if (marker === fence.marker && size >= fence.size) fence = null;
      inlineCodeMarkerSize = 0;
      normalized.push(line);
      continue;
    }

    if (fence) {
      normalized.push(line);
      continue;
    }

    const rawCodeOpen = line.match(/<(code|pre|script|style)\b/i);
    if (rawCodeOpen) {
      const tag = rawCodeOpen[1].toLowerCase();
      const remainder = line.slice((rawCodeOpen.index ?? 0) + rawCodeOpen[0].length);
      if (!new RegExp(`</${tag}\\s*>`, "i").test(remainder)) rawCodeTag = tag;
      inlineCodeMarkerSize = 0;
      normalized.push(line);
      continue;
    }

    if (/^(?: {4}|\t)/.test(line) || line.trim() === "") {
      inlineCodeMarkerSize = 0;
      normalized.push(line);
      continue;
    }

    if (!inlineCodeMarkerSize) line = rewriteEscapedInlineCodeBackticks(line);

    if (inlineCodeMarkerSize || line.includes("`")) {
      inlineCodeMarkerSize = updateInlineCodeMarker(line, inlineCodeMarkerSize);
      normalized.push(line);
      continue;
    }

    const bracketDisplayOneLine = line.match(/^([ ]{0,3})\\\[[ \t]*(.+?)[ \t]*\\\][ \t]*$/);
    if (bracketDisplayOneLine) {
      const math = bracketDisplayOneLine[2].trim();
      if (math) {
        // Keep the content line indented together with the `$$` fence. When the
        // formula is nested inside a GFM list item (indented `$$`), a content line
        // at column 0 becomes a "lazy continuation" line, which makes remark-math
        // mis-parse the fence pair: the opening `$$` turns into an empty math node
        // and the closing one swallows the rest of the document as math content.
        normalized.push(
          `${bracketDisplayOneLine[1]}$$`,
          `${bracketDisplayOneLine[1]}${math}`,
          `${bracketDisplayOneLine[1]}$$`,
        );
        continue;
      }
    }

    const looseBracketDisplayOneLine = line.match(/^([ ]{0,3})\[[ \t]*(.+?)[ \t]*\][ \t]*$/);
    if (looseBracketDisplayOneLine) {
      const math = looseBracketDisplayOneLine[2].trim();
      if (isLikelyMathExpression(math)) {
        normalized.push(
          `${looseBracketDisplayOneLine[1]}$$`,
          `${looseBracketDisplayOneLine[1]}${math}`,
          `${looseBracketDisplayOneLine[1]}$$`,
        );
        continue;
      }
    }

    const bracketDisplayStart = line.match(/^([ ]{0,3})\\\[[ \t]*$/);
    if (bracketDisplayStart) {
      const closingIndex = findBracketDisplayClose(lines, index + 1);
      if (closingIndex !== -1) {
        // Same lazy-continuation guard as above: indent content lines that sit at
        // column 0 so the block stays parseable when nested inside a list item.
        normalized.push(
          `${bracketDisplayStart[1]}$$`,
          ...lines.slice(index + 1, closingIndex).map((mathLine) =>
            indentDisplayMathContent(mathLine, bracketDisplayStart[1]),
          ),
          `${bracketDisplayStart[1]}$$`,
        );
        index = closingIndex;
        continue;
      }
    }

    const displayMathMatch = line.match(/^([ \t]{0,3})\$\$(.+)\$\$[ \t]*$/);
    if (displayMathMatch) {
      const math = displayMathMatch[2].trim();
      if (math) {
        // See the comment on bracketDisplayOneLine: without matching indentation,
        // a formula nested in a GFM list item is mis-parsed by remark-math and the
        // text after the formula renders as a garbled KaTeX error block.
        normalized.push(
          `${displayMathMatch[1]}$$`,
          `${displayMathMatch[1]}${math}`,
          `${displayMathMatch[1]}$$`,
        );
        continue;
      }
    }

    // remark-math requires both `$$` delimiters to sit on their own lines, but
    // models also emit display math as a multi-line block where the opening `$$`
    // is glued to the first formula line and/or the closing `$$` is glued to the
    // end of the last one (`$$x = 1` + `y = 2$$`). Without normalization such a
    // block swallows the following text as math content and renders as garbage.
    const displayMathMultiLine = line.match(/^([ \t]{0,3})\$\$(.+)$/);
    if (displayMathMultiLine) {
      const indent = displayMathMultiLine[1];
      const firstLine = displayMathMultiLine[2].trimEnd();
      // Only treat this as a block opener if no other `$$` is embedded mid-line
      // (e.g. `$$x$$ and text` stays untouched and is rendered as inline math).
      if (firstLine && !firstLine.includes("$$")) {
        const closing = findDisplayMathClose(
          lines,
          index + 1,
          indent,
          unmatchedDisplayMathUntil,
        );
        if (closing) {
          normalized.push(`${indent}$$`, `${indent}${firstLine}`);
          for (let j = index + 1; j < closing.index; j++) {
            normalized.push(indentDisplayMathContent(lines[j], indent));
          }
          if (closing.content) normalized.push(`${indent}${closing.content}`);
          normalized.push(`${indent}$$`);
          index = closing.index;
          continue;
        }
      }
    }

    // Bare `$$` opener (possibly indented inside a GFM list item). Two problems
    // need fixing: (1) when the closing `$$` is glued to the last content line
    // (e.g. `z = w$$`) remark-math never finds a valid closing fence and swallows
    // the rest of the document; (2) inside a list item, content lines at column 0
    // are lazy continuations that break the math flow. Both are fixed by moving
    // the closing `$$` to its own line and re-indenting lazy content lines.
    // A column-0 block with a properly detached closing `$$` is left untouched
    // (remark-math already parses it correctly).
    const displayMathBareOpen = line.match(/^([ \t]{0,3})\$\$\s*$/);
    if (displayMathBareOpen) {
      const indent = displayMathBareOpen[1];
      const closing = findDisplayMathClose(
        lines,
        index + 1,
        indent,
        unmatchedDisplayMathUntil,
      );
      if (closing && (closing.glued || indent !== "")) {
        normalized.push(`${indent}$$`);
        for (let j = index + 1; j < closing.index; j++) {
          normalized.push(indentDisplayMathContent(lines[j], indent));
        }
        if (closing.content) normalized.push(`${indent}${closing.content}`);
        normalized.push(`${indent}$$`);
        index = closing.index;
        continue;
      }
    }

    normalized.push(normalizeInlineLatexMath(line));
  }

  return normalized.join(lineBreak);
}

interface DisplayMathClose {
  index: number;
  content: string;
  glued: boolean;
}

function findDisplayMathClose(
  lines: string[],
  startIndex: number,
  indent: string,
  unmatchedUntil: Map<string, number>,
): DisplayMathClose | null {
  const knownUnmatchedUntil = unmatchedUntil.get(indent);
  if (knownUnmatchedUntil !== undefined && startIndex < knownUnmatchedUntil) return null;

  for (let index = startIndex; index < lines.length; index++) {
    const line = lines[index];
    if (isDisplayMathFence(line, indent)) return { index, content: "", glued: false };

    // A new Markdown block cannot belong to the preceding formula. In particular,
    // do not let a later sibling list item provide a closing `$$` for this block.
    if (isDisplayMathBlockBoundary(line) || isDisplayMathOpeningLine(line)) {
      unmatchedUntil.set(indent, index);
      return null;
    }

    const content = getDisplayMathGluedCloseContent(line, indent);
    if (content !== null) return { index, content, glued: true };
  }

  // Multiple unmatched glued openers with the same indentation previously each
  // scanned to EOF. Cache this range so the overall search remains linear.
  unmatchedUntil.set(indent, lines.length);
  return null;
}

function isDisplayMathFence(line: string, indent: string): boolean {
  if (indent === "") return /^ {0,3}\$\$\s*$/.test(line);
  return line.startsWith(indent) && /^\$\$\s*$/.test(line.slice(indent.length));
}

function getDisplayMathGluedCloseContent(line: string, indent: string): string | null {
  if (!line.startsWith(indent)) return null;

  const match = line.slice(indent.length).match(/^(.+?)\$\$\s*$/);
  if (!match) return null;

  const content = match[1].trimEnd();
  return content && !content.includes("$$") ? content : null;
}

function isDisplayMathOpeningLine(line: string): boolean {
  return /^ {0,3}\$\$(?:\S|[ \t]+\S)/.test(line);
}

function isDisplayMathBlockBoundary(line: string): boolean {
  return (
    /^ {0,3}(`{3,}|~{3,})/.test(line) ||
    /^[ \t]*(?:[-+*]|\d{1,9}[.)])(?:[ \t]+|$)/.test(line) ||
    /^ {0,3}#{1,6}(?:[ \t]+|$)/.test(line) ||
    /^ {0,3}>/.test(line) ||
    /<(code|pre|script|style)\b/i.test(line)
  );
}

function indentDisplayMathContent(line: string, indent: string): string {
  if (!indent || !line || line.startsWith("\t")) return line;

  const leadingSpaces = line.match(/^ */)?.[0].length ?? 0;
  if (leadingSpaces >= indent.length) return line;
  return `${indent.slice(leadingSpaces)}${line}`;
}

function findBracketDisplayClose(lines: string[], startIndex: number): number {
  for (let index = startIndex; index < lines.length; index++) {
    const line = lines[index];
    if (/^ {0,3}\\\][ \t]*$/.test(line)) return index;

    // Do not pair delimiters across another Markdown block boundary.
    if (
      /^ {0,3}(`{3,}|~{3,})/.test(line) ||
      /^ {0,3}\\\[[ \t]*$/.test(line) ||
      /<(code|pre|script|style)\b/i.test(line)
    ) {
      return -1;
    }
  }

  return -1;
}

function updateInlineCodeMarker(line: string, initialMarkerSize: number): number {
  let markerSize = initialMarkerSize;
  for (let cursor = 0; cursor < line.length;) {
    if (line[cursor] !== "`") {
      cursor++;
      continue;
    }

    let end = cursor + 1;
    while (line[end] === "`") end++;
    const runSize = end - cursor;
    if (markerSize === 0) markerSize = runSize;
    else if (runSize === markerSize) markerSize = 0;
    cursor = end;
  }
  return markerSize;
}

// `\(` … `\)` whose closing backslash is not itself escaped.
const inlineLatexMathPattern = /\\\(([^`\r\n$]*?[^`\r\n$\\])\\\)/y;

function normalizeInlineLatexMath(line: string): string {
  if (
    /^\s{0,3}\[[^\]]+\]:/.test(line) ||
    /]\s*\(/.test(line) ||
    /<(?:!--|\/?[A-Za-z][^>]*>)/.test(line) ||
    /\b(?:https?|file|mailto):/i.test(line) ||
    /\b[A-Za-z]:\\/.test(line)
  ) {
    return line;
  }

  return replaceNotPrecededBy(line, "\\(", "\\", inlineLatexMathPattern, ([match, math]) =>
    math.trim() ? `$${math}$` : match,
  );
}

function isLikelyMathExpression(value: string): boolean {
  return /\\[A-Za-z]+/.test(value) && !/\b(?:https?|file|mailto):|\b[A-Za-z]:\\|^\\\\/i.test(value);
}

// Parse YAML frontmatter into a `yaml` node before the math/GFM plugins run, so
// the raw metadata never leaks into the rendered output (without it, the opening
// `---` becomes an <hr> and the closing `---` turns the YAML into a setext heading).
// singleTilde:false requires ~~double~~ tildes for strikethrough. A single `~`
// is the standard CJK numeric-range separator (e.g. "5~7U", "100~200倍"), and
// GFM's default single-tilde strikethrough silently mangled such ranges (#385).
const remarkGfmOptions = { singleTilde: false } as const;

// GFM autolink literals (`https://…`, `www.…`) stop only at whitespace, and the
// trailing-punctuation trim knows only ASCII punctuation, so a URL glued to CJK
// prose swallows that prose: `https://a.com，见这里` becomes one link whose href
// is `https://a.com，见这里`, and clicking it goes nowhere.
//
// This is upstream behaviour rather than a bug in remark-gfm: it follows GitHub,
// which also terminates autolinks only on ASCII punctuation (remarkjs/remark-gfm#83
// was closed as not planned for exactly that reason, pointing at
// github/cmark-gfm#377 — the open spec request to accept non-ASCII terminators).
// Until that lands, split the literal here. CJK punctuation is the sentence
// boundary in Chinese/Japanese, so the URL stays clickable and the prose stays
// prose. Ideographs are deliberately NOT boundaries, so a genuine CJK path such
// as `https://zh.wikipedia.org/wiki/中文条目` keeps working.
const cjkPunctuationPattern =
  /[\u3001\u3002\u3008-\u3011\u3014-\u301B\uFF01\uFF08\uFF09\uFF0C\uFF1A\uFF1B\uFF1F\u2018\u2019\u201C\u201D\u2013\u2014\u2026\u00B7\uFF5E\u301C]/;

/**
 * Split every GFM autolink literal at its first CJK punctuation mark, turning the
 * trailing prose back into a plain text node.
 *
 * `source` must be the markdown the tree was parsed from. An autolink literal's
 * raw source **is** its text, while a hand-written `[text](url)` link's raw source
 * is `[text](url)` — comparing the two is what leaves explicit links untouched
 * even when their text happens to equal their url.
 */
export function splitAutolinkLiteralsAtCjkPunctuation(tree: Root, source: string): void {
  const walk = (node: Root | Parent): void => {
    const children = node.children as Content[];
    for (let index = 0; index < children.length; index++) {
      const child = children[index];
      if (child.type === "link") splitAutolinkLiteral(children, index, child, source);
      const current = children[index];
      if ("children" in current && Array.isArray(current.children)) walk(current as Parent);
    }
  };
  walk(tree);
}

function splitAutolinkLiteral(
  siblings: Content[],
  index: number,
  node: Link,
  source: string,
): void {
  if (node.title != null || node.children.length !== 1) return;
  const textNode = node.children[0];
  if (textNode.type !== "text") return;

  const start = node.position?.start;
  const end = node.position?.end;
  if (start?.offset == null || end?.offset == null) return;
  if (source.slice(start.offset, end.offset) !== textNode.value) return;

  const text = textNode.value;
  const cut = text.search(cjkPunctuationPattern);
  // `cut === 0` means the literal itself starts with punctuation — not a URL.
  if (cut <= 0 || !node.url.endsWith(text)) return;

  const head = text.slice(0, cut);
  const boundary = { line: start.line, column: start.column + cut, offset: start.offset + cut };
  // The url carries a `http://` (www.) or `mailto:` prefix the text does not.
  node.url = node.url.slice(0, node.url.length - text.length) + head;
  textNode.value = head;
  node.position = { start, end: boundary };
  siblings.splice(index + 1, 0, {
    type: "text",
    value: text.slice(cut),
    position: { start: boundary, end },
  });
}

function remarkSplitAutolinkLiterals() {
  return (tree: Root, file: { value?: unknown }): void => {
    splitAutolinkLiteralsAtCjkPunctuation(tree, typeof file.value === "string" ? file.value : "");
  };
}

// Reject ambiguous single-dollar pairs during tokenization, before math can
// swallow Markdown emphasis or links. A price's next dollar ("$20 ... $6")
// cannot close math, nor can the space before a later formula ("$20 and $x$").
// Keep the upstream tokenizer/resolver for real math, code, escapes and $$.
const remarkCurrencySafeMath: Plugin = function () {
  remarkMath.call(this);
  const data = this.data() as { micromarkExtensions?: Extension[] };
  const extension = data.micromarkExtensions?.at(-1);
  const constructs = extension?.text?.[36];
  for (const construct of Array.isArray(constructs) ? constructs : constructs ? [constructs] : []) {
    if (construct.name !== "mathText") continue;
    const tokenize = construct.tokenize;
    construct.tokenize = function (effects, ok, nok) {
      const start = this.now();
      return tokenize.call(this, effects, (code) => {
        const source = this.sliceSerialize({ start, end: this.now() });
        if (source.startsWith("$") && !source.startsWith("$$")) {
          const content = source.slice(1, -1);
          const startsWithAmount = /^\s*[+-]?(?:\d|\.\d)/.test(content);
          const closesBeforeNumber = code !== null && code >= 48 && code <= 57;
          // Balanced padding ($ x + y $) remains supported, as does multiline
          // math. A one-sided space is prose, not an inline-math boundary.
          const mismatchedPadding = /^\s/.test(content) !== /\s$/.test(content);
          if (startsWithAmount && (closesBeforeNumber || mismatchedPadding)) return nok(code);
        }
        return ok(code);
      }, nok);
    };
  }
};

// Drive letters otherwise look like unknown URL schemes to the sanitizer.
// Rewrite only Markdown link destinations, before rehype and URL filtering.
function remarkWindowsFileLinks() {
  return (tree: Root): void => {
    const walk = (node: Root | Content): void => {
      if ((node.type === "link" || node.type === "definition") && /^\/?[A-Za-z]:\//.test(node.url)) {
        node.url = `file:///${node.url.replace(/^\//, "")}`;
      }
      if ("children" in node) node.children.forEach(walk);
    };
    walk(tree);
  };
}

export const markdownRemarkPlugins: ReactMarkdownOptions["remarkPlugins"] = [
  [remarkFrontmatter, ["yaml"]],
  [remarkGfm, remarkGfmOptions],
  remarkCjkFriendly,
  remarkSplitAutolinkLiterals,
  remarkCurrencySafeMath,
  remarkWindowsFileLinks,
];

// User messages keep every typed line break, as the TUI shows them (#680). The
// `.markdown-user-message p` pre-wrap rule only reaches paragraphs, so a soft
// break in a tight list item ("1. question\nA. option") or a heading collapsed
// into a space, and Chrome renders a lone `\r` as a space even under pre-wrap.
// Every line ending in text therefore becomes a <br>. It is a custom node that
// remark-rehype turns into a bare <br> through `data.hName`, not an mdast
// `break`: remark-rehype follows that <br> with a "\n" text node, which the
// pre-wrap rule renders as a second break, so hard breaks are swapped too. Code,
// inline code and math are other node types and keep their text.
interface MarkdownTreeNode {
  type: string;
  value?: string;
  children?: MarkdownTreeNode[];
  data?: { hName?: string };
}

const LINE_ENDING = /[ \t]*(?:\r\n|\r|\n)[ \t]*/;
// Containers whose children are blocks: an HTML block there becomes a paragraph.
const BLOCK_CONTAINER_TYPES = new Set(["root", "blockquote", "listItem", "footnoteDefinition"]);

function lineBreakNode(): MarkdownTreeNode {
  return { type: "lineBreak", data: { hName: "br" } };
}

// pi's TUI prints a user message's HTML as the characters typed (pi-tui's
// Markdown, `case "html"`), so a pasted `<TableOperator v-model="x" />` or
// `<textarea>` reads as written instead of being parsed by rehype-raw and
// stripped by the sanitizer (#1407). Runs before the line breaks are kept, so
// a multi-line tag breaks like any text.
function htmlAsText(parent: MarkdownTreeNode): void {
  if (!parent.children) return;
  const blockParent = BLOCK_CONTAINER_TYPES.has(parent.type);
  parent.children = parent.children.map((node) => {
    if (node.type !== "html") {
      htmlAsText(node);
      return node;
    }
    const text = { type: "text", value: node.value ?? "" };
    return blockParent ? { type: "paragraph", children: [text] } : text;
  });
}

function keepLineBreaks(parent: MarkdownTreeNode): void {
  if (!parent.children) return;
  parent.children = parent.children.flatMap((node) => {
    if (node.type === "break") return [lineBreakNode()];
    if (node.type !== "text" || !node.value) {
      keepLineBreaks(node);
      return [node];
    }
    return node.value.split(LINE_ENDING).flatMap((line, index) => [
      ...(index > 0 ? [lineBreakNode()] : []),
      ...(line ? [{ type: "text", value: line }] : []),
    ]);
  });
}

function remarkUserText() {
  return (tree: MarkdownTreeNode) => {
    htmlAsText(tree);
    keepLineBreaks(tree);
  };
}

export const markdownUserRemarkPlugins: ReactMarkdownOptions["remarkPlugins"] = [
  ...(markdownRemarkPlugins ?? []),
  remarkUserText,
];
export const markdownPreviewRemarkPlugins: ReactMarkdownOptions["remarkPlugins"] = [
  [remarkFrontmatter, ["yaml"]],
  [remarkGfm, remarkGfmOptions],
  remarkCjkFriendly,
  remarkSplitAutolinkLiterals,
  remarkCurrencySafeMath,
  remarkWindowsFileLinks,
];

interface SanitizedNode {
  type?: string;
  properties?: Record<string, unknown>;
  children?: SanitizedNode[];
}

/**
 * GitHub rewrites both sides of a content anchor. cmark-gfm prefixes rendered
 * `id`s with `user-content-` (anti-clobber) and rewrites same-document fragment
 * links to match, so a hand-written pair like `<a id="toc"></a>` with
 * `[ToC](#toc)` still lands after rendering. `rehype-sanitize` copies only the
 * `id` half of that — `defaultSchema`'s `clobber` + `clobberPrefix` — which on
 * its own breaks every in-document anchor pair: the element gains the prefix
 * and the link pointing at it does not.
 *
 * This plugin runs after sanitizing and prefixes fragment links exactly as
 * unconditionally as sanitizing prefixes ids, so an id and an href that matched
 * before sanitizing still match afterwards. Footnote references need it for the
 * same reason: `mdast-util-to-hast` generates both their sides already prefixed
 * and sanitizing prefixes the id once more, so an unprefixed href would strand
 * the footnote link behind the doubled prefix.
 *
 * Links to page elements keep being unreachable from Markdown — that is the
 * clobber protection doing its job, not this plugin. A bare `#` has no fragment
 * to pair and stays as written.
 */
function rehypeMatchClobberedIds(): (tree: unknown) => void {
  return (tree: unknown): void => {
    const visit = (node: SanitizedNode): void => {
      if (!node || typeof node !== "object") return;
      const href = node.properties?.href;
      if (node.type === "element" && typeof href === "string" && href.startsWith("#") && href.length > 1) {
        node.properties!.href = `#${markdownClobberPrefix}${href.slice(1)}`;
      }
      for (const child of node.children ?? []) visit(child);
    };
    visit(tree as SanitizedNode);
  };
}

function hastText(node: HastContent): string {
  return node.type === "text" ? node.value : node.type === "element" ? node.children.map(hastText).join("") : "";
}

/**
 * Display math (`$$…$$`, a ```math fence: `<pre><code class="language-math">`)
 * goes into a `<div data-math-source>` holding its LaTeX, which MarkdownBody
 * gives a Copy button (#1380). KaTeX then renders the formula inside the div;
 * its glyphs are no source to copy. Runs after sanitizing, so the attribute is
 * never one a user's own HTML could carry (the schema drops `data-*`), and
 * inline math (no `<pre>`) stays as it is.
 */
function rehypeDisplayMathSource() {
  return (tree: HastRoot): void => {
    const visit = (parent: HastRoot | HastElement): void => {
      parent.children = parent.children.map((child) => {
        if (child.type !== "element") return child;
        const code = child.tagName === "pre" && child.children.length === 1 ? child.children[0] : null;
        const classes = code?.type === "element" && code.tagName === "code" ? code.properties.className : null;
        if (Array.isArray(classes) && classes.includes("language-math")) {
          return {
            type: "element",
            tagName: "div",
            properties: { className: ["markdown-math-display"], dataMathSource: hastText(child).replace(/\n$/, "") },
            children: [child],
          };
        }
        visit(child);
        return child;
      });
    };
    visit(tree);
  };
}

export const markdownRehypePlugins: ReactMarkdownOptions["rehypePlugins"] = [
  rehypeRaw,
  [rehypeSanitize, markdownSanitizeSchema],
  rehypeMatchClobberedIds,
  rehypeDisplayMathSource,
  [rehypeKatex, { throwOnError: false, strict: false }],
];

/** GitHub's heading slugs for `#fragment` links, as a data attribute: two rendered documents never share an id. */
function markdownHeadingAnchors() {
  return (tree: HastRoot) => {
    const seen = new Map<string, number>();
    const visit = (node: HastRoot | HastElement) => node.children.forEach((child) => {
      if (child.type !== "element") return;
      if (/^h[1-6]$/.test(child.tagName)) {
        const base = hastText(child).toLowerCase().replace(/[^\p{L}\p{M}\p{N}_\- ]/gu, "").replace(/ /g, "-");
        // As github-slugger numbers repeats: "a", "a", "a-1" become a, a-1, a-1-1.
        let slug = base;
        while (seen.has(slug)) {
          seen.set(base, seen.get(base)! + 1);
          slug = `${base}-${seen.get(base)}`;
        }
        seen.set(slug, 0);
        child.properties.dataHeadingAnchor = slug;
      }
      visit(child);
    });
    visit(tree);
  };
}

// A document whose `#fragment` links lead to its headings (Settings › Skills).
// Anchors come before KaTeX, which writes each formula's text twice.
export const markdownDocumentRehypePlugins: ReactMarkdownOptions["rehypePlugins"] = [
  rehypeRaw,
  [rehypeSanitize, markdownSanitizeSchema],
  markdownHeadingAnchors,
  rehypeDisplayMathSource,
  [rehypeKatex, { throwOnError: false, strict: false }],
];

export const markdownPreviewRehypePlugins: ReactMarkdownOptions["rehypePlugins"] = [
  rehypeRaw,
  [rehypeSanitize, markdownSanitizeSchema],
  rehypeMatchClobberedIds,
  [rehypeKatex, { throwOnError: false, strict: false }],
];
